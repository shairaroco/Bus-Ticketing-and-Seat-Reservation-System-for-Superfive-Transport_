package LoginRegister;

public class PassengerAdminAccount {

    public static int userId;
    public static String fullName;
    public static String email;
    public static String username;
    public static String password;
    
    public static String adminUsername = "admin";
    public static String adminPassword = "admin123";
}