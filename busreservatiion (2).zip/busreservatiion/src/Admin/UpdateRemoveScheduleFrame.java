
package Admin   ;

import LoginRegister.SuperFiveFrame;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

    
public class UpdateRemoveScheduleFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(UpdateRemoveScheduleFrame.class.getName());

    int scheduleID = 1;   
     
    public UpdateRemoveScheduleFrame() {
        initComponents();
        loadDatabaseSchedules();
        tblSchedules.getSelectionModel().addListSelectionListener(e -> {

    if (!e.getValueIsAdjusting()) {

        int row = tblSchedules.getSelectedRow();

        if (row != -1) {

            cmbFrom.setSelectedItem(
                    tblSchedules.getValueAt(row, 2).toString()
            );

            cmbTo.setSelectedItem(
                    tblSchedules.getValueAt(row, 3).toString()
            );

            txtTravelDate.setText(
                    tblSchedules.getValueAt(row, 4).toString()
            );

            txtDepartureTime.setText(
                    tblSchedules.getValueAt(row, 5).toString()
            );

            txtBusNo.setText(
                    tblSchedules.getValueAt(row, 1).toString()
            );

            txtFare.setText(
                    tblSchedules.getValueAt(row, 6)
                            .toString()
                            .replace("PHP ", "")
            );
        }
    }
});
    }
    
    
    // Kuhaon ang schedules gikan sa database (from/to null = tanan)
    private void loadDatabaseSchedules() {
        loadSchedulesFromDb(null, null);
    }

    private void loadSchedulesFromDb(String from, String to) {
        DefaultTableModel model = (DefaultTableModel) tblSchedules.getModel();
        model.setRowCount(0);

        for (Object[] row : Database.ScheduleDB.getSchedules(from, to)) {
            model.addRow(row);
        }
    }

    private int getFare(String from, String to) {

    if ((from.equals("CDO") && to.equals("Wao")) ||
        (from.equals("Wao") && to.equals("CDO"))) {
        return 350;
    }

    if ((from.equals("CDO") && to.equals("Dipolog")) ||
        (from.equals("Dipolog") && to.equals("CDO"))) {
        return 550;
    }

    if ((from.equals("CDO") && to.equals("Pagadian")) ||
        (from.equals("Pagadian") && to.equals("CDO"))) {
        return 450;
    }

    if ((from.equals("CDO") && to.equals("Maramag")) ||
        (from.equals("Maramag") && to.equals("CDO"))) {
        return 300;
    }

    if ((from.equals("CDO") && to.equals("Tubod")) ||
        (from.equals("Tubod") && to.equals("CDO"))) {
        return 400;
    }

    if ((from.equals("CDO") && to.equals("Kibawe")) ||
        (from.equals("Kibawe") && to.equals("CDO"))) {
        return 350;
    }

    if ((from.equals("CDO") && to.equals("Ozamiz")) ||
        (from.equals("Ozamiz") && to.equals("CDO"))) {
        return 500;
    }

    return 0;
}
 private void loadCurrentSchedules() {

    DefaultTableModel model =
            (DefaultTableModel) tblSchedules.getModel();

    model.setRowCount(0);

    // CDO TO WAO
    model.addRow(new Object[]{
        "CDO TO WAO", "", "", "", "", "", "", ""
    });

    model.addRow(new Object[]{
        "SF1", "BUS-01", "CDO", "Wao",
        "10/07/2026", "8:00 AM", "PHP 350", "44"
    });

    model.addRow(new Object[]{
        "SF2", "BUS-02", "CDO", "Wao",
        "10/07/2026", "10:00 AM", "PHP 350", "44"
    });

    model.addRow(new Object[]{
        "SF3", "BUS-03", "CDO", "Wao",
        "10/07/2026", "1:00 PM", "PHP 350", "44"
    });

    model.addRow(new Object[]{
        "SF4", "BUS-04", "CDO", "Wao",
        "10/07/2026", "4:00 PM", "PHP 350", "44"
    });

    // CDO TO DIPOLOG
    model.addRow(new Object[]{
        "CDO TO DIPOLOG", "", "", "", "", "", "", ""
    });

    model.addRow(new Object[]{
        "SF5", "BUS-05", "CDO", "Dipolog",
        "10/07/2026", "8:00 AM", "PHP 550", "44"
    });

    model.addRow(new Object[]{
        "SF6", "BUS-06", "CDO", "Dipolog",
        "10/07/2026", "10:00 AM", "PHP 550", "44"
    });

    model.addRow(new Object[]{
        "SF7", "BUS-07", "CDO", "Dipolog",
        "10/07/2026", "1:00 PM", "PHP 550", "44"
    });

    model.addRow(new Object[]{
        "SF8", "BUS-08", "CDO", "Dipolog",
        "10/07/2026", "4:00 PM", "PHP 550", "44"
    });

    // CDO TO PAGADIAN
    model.addRow(new Object[]{
        "CDO TO PAGADIAN", "", "", "", "", "", "", ""
    });

    model.addRow(new Object[]{
        "SF9", "BUS-09", "CDO", "Pagadian",
        "10/07/2026", "8:00 AM", "PHP 450", "44"
    });

    model.addRow(new Object[]{
        "SF10", "BUS-10", "CDO", "Pagadian",
        "10/07/2026", "10:00 AM", "PHP 450", "44"
    });

    model.addRow(new Object[]{
        "SF11", "BUS-11", "CDO", "Pagadian",
        "10/07/2026", "1:00 PM", "PHP 450", "44"
    });

    model.addRow(new Object[]{
        "SF12", "BUS-12", "CDO", "Pagadian",
        "10/07/2026", "4:00 PM", "PHP 450", "44"
    });

    // CDO TO MARAMAG
    model.addRow(new Object[]{
        "CDO TO MARAMAG", "", "", "", "", "", "", ""
    });

    model.addRow(new Object[]{
        "SF13", "BUS-13", "CDO", "Maramag",
        "10/07/2026", "8:00 AM", "PHP 300", "44"
    });

    model.addRow(new Object[]{
        "SF14", "BUS-14", "CDO", "Maramag",
        "10/07/2026", "10:00 AM", "PHP 300", "44"
    });

    model.addRow(new Object[]{
        "SF15", "BUS-15", "CDO", "Maramag",
        "10/07/2026", "1:00 PM", "PHP 300", "44"
    });

    model.addRow(new Object[]{
        "SF16", "BUS-16", "CDO", "Maramag",
        "10/07/2026", "4:00 PM", "PHP 300", "44"
    });

    // CDO TO TUBOD
    model.addRow(new Object[]{
        "CDO TO TUBOD", "", "", "", "", "", "", ""
    });

    model.addRow(new Object[]{
        "SF17", "BUS-17", "CDO", "Tubod",
        "10/07/2026", "8:00 AM", "PHP 400", "44"
    });

    model.addRow(new Object[]{
        "SF18", "BUS-18", "CDO", "Tubod",
        "10/07/2026", "10:00 AM", "PHP 400", "44"
    });

    model.addRow(new Object[]{
        "SF19", "BUS-19", "CDO", "Tubod",
        "10/07/2026", "1:00 PM", "PHP 400", "44"
    });

    model.addRow(new Object[]{
        "SF20", "BUS-20", "CDO", "Tubod",
        "10/07/2026", "4:00 PM", "PHP 400", "44"
    });

    // CDO TO KIBAWE
    model.addRow(new Object[]{
        "CDO TO KIBAWE", "", "", "", "", "", "", ""
    });

    model.addRow(new Object[]{
        "SF21", "BUS-21", "CDO", "Kibawe",
        "10/07/2026", "8:00 AM", "PHP 350", "44"
    });

    model.addRow(new Object[]{
        "SF22", "BUS-22", "CDO", "Kibawe",
        "10/07/2026", "10:00 AM", "PHP 350", "44"
    });

    model.addRow(new Object[]{
        "SF23", "BUS-23", "CDO", "Kibawe",
        "10/07/2026", "1:00 PM", "PHP 350", "44"
    });

    model.addRow(new Object[]{
        "SF24", "BUS-24", "CDO", "Kibawe",
        "10/07/2026", "4:00 PM", "PHP 350", "44"
    });

    // CDO TO OZAMIZ
    model.addRow(new Object[]{
        "CDO TO OZAMIZ", "", "", "", "", "", "", ""
    });

    model.addRow(new Object[]{
        "SF25", "BUS-25", "CDO", "Ozamiz",
        "10/07/2026", "8:00 AM", "PHP 500", "44"
    });

    model.addRow(new Object[]{
        "SF26", "BUS-26", "CDO", "Ozamiz",
        "10/07/2026", "10:00 AM", "PHP 500", "44"
    });

    model.addRow(new Object[]{
        "SF27", "BUS-27", "CDO", "Ozamiz",
        "10/07/2026", "1:00 PM", "PHP 500", "44"
    });

    model.addRow(new Object[]{
        "SF28", "BUS-28", "CDO", "Ozamiz",
        "10/07/2026", "4:00 PM", "PHP 500", "44"
    });
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlMain = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        pnlTop1 = new javax.swing.JPanel();
        cmbFrom1 = new javax.swing.JComboBox<>();
        jLabel19 = new javax.swing.JLabel();
        cmbTo1 = new javax.swing.JComboBox<>();
        jLabel20 = new javax.swing.JLabel();
        txtTravelDate1 = new javax.swing.JTextField();
        btnSearch1 = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        btnExchange1 = new javax.swing.JButton();
        btnDate1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        pnlAddRemove = new javax.swing.JPanel();
        pnlSidebar = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnHome = new javax.swing.JButton();
        btnSchedule = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        btnBookingRecord = new javax.swing.JButton();
        btnContact = new javax.swing.JButton();
        pnlMain1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        cmbFrom = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        cmbTo = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        txtTravelDate = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtDepartureTime = new javax.swing.JTextField();
        btnUpdateSchedule = new javax.swing.JButton();
        btnRemove = new javax.swing.JButton();
        txtBusNo = new javax.swing.JTextField();
        lblMessage = new javax.swing.JLabel();
        txtFare = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSchedules = new javax.swing.JTable();
        btnBack = new javax.swing.JButton();
        pnlTop2 = new javax.swing.JPanel();
        cmbFrom2 = new javax.swing.JComboBox<>();
        jLabel22 = new javax.swing.JLabel();
        cmbTo2 = new javax.swing.JComboBox<>();
        jLabel23 = new javax.swing.JLabel();
        btnSearch2 = new javax.swing.JButton();
        btnExchange2 = new javax.swing.JButton();

        pnlMain.setBackground(new java.awt.Color(204, 204, 204));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setText("Welcome, Admin");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Manage schedules, view bookings ,and keeps the runnning system smoothly.");

        javax.swing.GroupLayout pnlMainLayout = new javax.swing.GroupLayout(pnlMain);
        pnlMain.setLayout(pnlMainLayout);
        pnlMainLayout.setHorizontalGroup(
            pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMainLayout.createSequentialGroup()
                .addGroup(pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlMainLayout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 536, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlMainLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel4)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlMainLayout.setVerticalGroup(
            pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMainLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(18, 18, 18))
        );

        pnlTop1.setBackground(new java.awt.Color(250, 248, 227));

        cmbFrom1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cmbFrom1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CDO", "Wao", "Dipolog", "Pagadian", "Maramag", "Tubod", "Kibawe", "Ozamiz" }));
        cmbFrom1.addActionListener(this::cmbFrom1ActionPerformed);

        jLabel19.setText("FROM");

        cmbTo1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cmbTo1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CDO", "Wao", "Dipolog", "Pagadian", "Maramag", "Tubod", "Kibawe", "Ozamiz" }));
        cmbTo1.addActionListener(this::cmbTo1ActionPerformed);

        jLabel20.setText("TO");

        txtTravelDate1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        txtTravelDate1.addActionListener(this::txtTravelDate1ActionPerformed);

        btnSearch1.setBackground(new java.awt.Color(30, 105, 75));
        btnSearch1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSearch1.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch1.setText("SEARCH");
        btnSearch1.addActionListener(this::btnSearch1ActionPerformed);

        jLabel21.setText("TRAVEL DATE");

        btnExchange1.setText("⇄");
        btnExchange1.addActionListener(this::btnExchange1ActionPerformed);

        btnDate1.setForeground(new java.awt.Color(30, 105, 75));
        btnDate1.setText("📅");
        btnDate1.addActionListener(this::btnDate1ActionPerformed);

        javax.swing.GroupLayout pnlTop1Layout = new javax.swing.GroupLayout(pnlTop1);
        pnlTop1.setLayout(pnlTop1Layout);
        pnlTop1Layout.setHorizontalGroup(
            pnlTop1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTop1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlTop1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlTop1Layout.createSequentialGroup()
                        .addComponent(cmbFrom1, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnExchange1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(pnlTop1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlTop1Layout.createSequentialGroup()
                        .addComponent(cmbTo1, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtTravelDate1, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnDate1, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnSearch1, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlTop1Layout.createSequentialGroup()
                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(299, 299, 299)
                        .addComponent(jLabel21)))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        pnlTop1Layout.setVerticalGroup(
            pnlTop1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTop1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlTop1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel21, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(pnlTop1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel19)
                        .addComponent(jLabel20)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlTop1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearch1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDate1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTravelDate1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbTo1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExchange1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbFrom1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlAddRemove.setBackground(new java.awt.Color(204, 204, 204));

        pnlSidebar.setBackground(new java.awt.Color(30, 105, 75));
        pnlSidebar.setForeground(new java.awt.Color(153, 153, 153));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("BUS RESERVATION ");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("SYSTEM");

        btnHome.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnHome.setForeground(new java.awt.Color(30, 105, 75));
        btnHome.setText("Home");
        btnHome.addActionListener(this::btnHomeActionPerformed);

        btnSchedule.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSchedule.setForeground(new java.awt.Color(30, 105, 75));
        btnSchedule.setText("Update/Remove Schedule");
        btnSchedule.addActionListener(this::btnScheduleActionPerformed);

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(30, 105, 75));
        jButton1.setText("Log out");
        jButton1.addActionListener(this::jButton1ActionPerformed);

        btnBookingRecord.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBookingRecord.setForeground(new java.awt.Color(30, 105, 75));
        btnBookingRecord.setText("Booking Record");
        btnBookingRecord.addActionListener(this::btnBookingRecordActionPerformed);

        btnContact.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnContact.setForeground(new java.awt.Color(30, 105, 75));
        btnContact.setText("Passenger Concern/Feedback");
        btnContact.addActionListener(this::btnContactActionPerformed);

        javax.swing.GroupLayout pnlSidebarLayout = new javax.swing.GroupLayout(pnlSidebar);
        pnlSidebar.setLayout(pnlSidebarLayout);
        pnlSidebarLayout.setHorizontalGroup(
            pnlSidebarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator1)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlSidebarLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(95, 95, 95))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlSidebarLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(27, 27, 27))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlSidebarLayout.createSequentialGroup()
                .addGroup(pnlSidebarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlSidebarLayout.createSequentialGroup()
                        .addGap(98, 98, 98)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlSidebarLayout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addGroup(pnlSidebarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnSchedule, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnBookingRecord, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnContact, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnHome, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(47, 47, 47))
        );
        pnlSidebarLayout.setVerticalGroup(
            pnlSidebarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSidebarLayout.createSequentialGroup()
                .addGap(134, 134, 134)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addGap(69, 69, 69)
                .addComponent(btnHome, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(btnSchedule, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnBookingRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnContact, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jButton1)
                .addGap(16, 16, 16))
        );

        pnlMain1.setBackground(new java.awt.Color(30, 105, 75));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Welcome, Admin");

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Manage schedules, view bookings ,and keeps the runnning system smoothly.");

        javax.swing.GroupLayout pnlMain1Layout = new javax.swing.GroupLayout(pnlMain1);
        pnlMain1.setLayout(pnlMain1Layout);
        pnlMain1Layout.setHorizontalGroup(
            pnlMain1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMain1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(pnlMain1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 536, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlMain1Layout.setVerticalGroup(
            pnlMain1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMain1Layout.createSequentialGroup()
                .addContainerGap(32, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addGap(39, 39, 39))
        );

        jPanel2.setBackground(new java.awt.Color(30, 105, 75));

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Schedule Details");

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));

        jLabel7.setText("From:");

        cmbFrom.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CDO", "Wao", "Dipolog", "Pagadian", "Maramag", "Tubod", "Kibawe", "Ozamiz", " " }));

        jLabel8.setText("To:");

        cmbTo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CDO", "Wao", "Dipolog", "Pagadian", "Maramag", "Tubod", "Kibawe", "Ozamiz", " " }));

        jLabel9.setText("Travel Date:");

        jLabel10.setText("Departure Time:");

        jLabel11.setText("Bus.No");

        btnUpdateSchedule.setBackground(new java.awt.Color(30, 105, 75));
        btnUpdateSchedule.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnUpdateSchedule.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdateSchedule.setText("Update Schedule");
        btnUpdateSchedule.addActionListener(this::btnUpdateScheduleActionPerformed);

        btnRemove.setBackground(new java.awt.Color(30, 105, 75));
        btnRemove.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRemove.setForeground(new java.awt.Color(255, 255, 255));
        btnRemove.setText("Remove Schedule");
        btnRemove.addActionListener(this::btnRemoveActionPerformed);

        txtFare.addActionListener(this::txtFareActionPerformed);

        jLabel14.setText("Fare");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(82, 82, 82))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtFare, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cmbFrom, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmbTo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtTravelDate)
                    .addComponent(txtDepartureTime, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtBusNo, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(btnUpdateSchedule)
                .addGap(18, 18, 18)
                .addComponent(btnRemove)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(cmbFrom, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbTo, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTravelDate, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDepartureTime, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txtBusNo, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtFare, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblMessage)
                .addGap(28, 28, 28)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnUpdateSchedule)
                    .addComponent(btnRemove))
                .addContainerGap(37, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(30, 105, 75));

        jLabel13.setBackground(new java.awt.Color(255, 255, 255));
        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Current Schedules");

        jPanel5.setBackground(new java.awt.Color(204, 204, 204));

        tblSchedules.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Schedule ID", "Bus No.", "From", "To", "Date", "Departure", "Fare", "Seats"
            }
        ));
        jScrollPane1.setViewportView(tblSchedules);

        btnBack.setBackground(new java.awt.Color(30, 105, 75));
        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.addActionListener(this::btnBackActionPerformed);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 702, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnBack)
                .addGap(21, 21, 21))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnBack)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlTop2.setBackground(new java.awt.Color(255, 255, 255));

        cmbFrom2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cmbFrom2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CDO", "Wao", "Dipolog", "Pagadian", "Maramag", "Tubod", "Kibawe", "Ozamiz" }));
        cmbFrom2.addActionListener(this::cmbFrom2ActionPerformed);

        jLabel22.setText("FROM");

        cmbTo2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cmbTo2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CDO", "Wao", "Dipolog", "Pagadian", "Maramag", "Tubod", "Kibawe", "Ozamiz" }));
        cmbTo2.addActionListener(this::cmbTo2ActionPerformed);

        jLabel23.setText("TO");

        btnSearch2.setBackground(new java.awt.Color(30, 105, 75));
        btnSearch2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSearch2.setForeground(new java.awt.Color(255, 255, 255));
        btnSearch2.setText("SEARCH");
        btnSearch2.addActionListener(this::btnSearch2ActionPerformed);

        btnExchange2.setText("⇄");
        btnExchange2.addActionListener(this::btnExchange2ActionPerformed);

        javax.swing.GroupLayout pnlTop2Layout = new javax.swing.GroupLayout(pnlTop2);
        pnlTop2.setLayout(pnlTop2Layout);
        pnlTop2Layout.setHorizontalGroup(
            pnlTop2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTop2Layout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addGroup(pnlTop2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlTop2Layout.createSequentialGroup()
                        .addComponent(cmbFrom2, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38)
                        .addComponent(btnExchange2, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(pnlTop2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlTop2Layout.createSequentialGroup()
                        .addComponent(cmbTo2, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39)
                        .addComponent(btnSearch2, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(162, Short.MAX_VALUE))
        );
        pnlTop2Layout.setVerticalGroup(
            pnlTop2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTop2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlTop2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlTop2Layout.createSequentialGroup()
                        .addGroup(pnlTop2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel22)
                            .addComponent(jLabel23))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(pnlTop2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnExchange2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbFrom2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnlTop2Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(pnlTop2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnSearch2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbTo2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        javax.swing.GroupLayout pnlAddRemoveLayout = new javax.swing.GroupLayout(pnlAddRemove);
        pnlAddRemove.setLayout(pnlAddRemoveLayout);
        pnlAddRemoveLayout.setHorizontalGroup(
            pnlAddRemoveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAddRemoveLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlSidebar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlAddRemoveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlAddRemoveLayout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(pnlMain1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlTop2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        pnlAddRemoveLayout.setVerticalGroup(
            pnlAddRemoveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlSidebar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(pnlAddRemoveLayout.createSequentialGroup()
                .addComponent(pnlMain1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlTop2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                .addGroup(pnlAddRemoveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlAddRemove, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlAddRemove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHomeActionPerformed
       AdminDashboard frame = new AdminDashboard();
        frame.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnHomeActionPerformed

    private void btnScheduleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnScheduleActionPerformed
       UpdateRemoveScheduleFrame frame = new UpdateRemoveScheduleFrame();
        frame.setVisible(true);
    }//GEN-LAST:event_btnScheduleActionPerformed

    private void btnRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoveActionPerformed
        int row = tblSchedules.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a schedule first.");
            return;
        }

        int answer = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to remove this schedule?",
                "Remove Schedule",
                JOptionPane.YES_NO_OPTION
        );

        if (answer == JOptionPane.YES_OPTION) {
            DefaultTableModel model =
                    (DefaultTableModel) tblSchedules.getModel();

            int scheduleId = Integer.parseInt(model.getValueAt(row, 0).toString());
            String error = Database.ScheduleDB.deleteSchedule(scheduleId);

            if (error != null) {
                JOptionPane.showMessageDialog(this, error);
                return;
            }

           loadDatabaseSchedules();
           JOptionPane.showMessageDialog(this, "Schedule removed successfully.");
        }
    }//GEN-LAST:event_btnRemoveActionPerformed

    private void btnUpdateScheduleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateScheduleActionPerformed
       
        int row = tblSchedules.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a schedule first.");
            return;
        }

        String from = cmbFrom.getSelectedItem().toString();
        String to = cmbTo.getSelectedItem().toString();
        String date = txtTravelDate.getText().trim();
        String time = txtDepartureTime.getText().trim();
        String busNo = txtBusNo.getText().trim();

        if (from.equals(to) || date.isEmpty() || time.isEmpty() || busNo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please complete all information.");
            return;
        }

        int fare = getFare(from, to);

        if (fare == 0) {
            JOptionPane.showMessageDialog(this, "This route is not available.");
            return;
        }

        // gamita ang fare nga gi-type sa admin (kung sakto)
        try {
            int typedFare = Integer.parseInt(txtFare.getText().trim().replace("PHP", "").trim());
            if (typedFare > 0) {
                fare = typedFare;
            }
        } catch (NumberFormatException ex) {
            // gamiton ang default fare sa route
        }

        DefaultTableModel model =
                (DefaultTableModel) tblSchedules.getModel();

        int scheduleId = Integer.parseInt(model.getValueAt(row, 0).toString());
        String error = Database.ScheduleDB.updateSchedule(
                scheduleId, busNo, from, to, date, time, fare);

        if (error != null) {
            JOptionPane.showMessageDialog(this, error);
            return;
        }

        model.setValueAt(busNo, row, 1);
        model.setValueAt(from, row, 2);
        model.setValueAt(to, row, 3);
        model.setValueAt(date, row, 4);
        model.setValueAt(time, row, 5);
        model.setValueAt("PHP " + fare, row, 6);

       
    loadDatabaseSchedules();
    JOptionPane.showMessageDialog(this, "Schedule updated successfully.");

    }//GEN-LAST:event_btnUpdateScheduleActionPerformed

    private void btnSearch1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearch1ActionPerformed

    }//GEN-LAST:event_btnSearch1ActionPerformed

    private void btnExchange1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExchange1ActionPerformed

    }//GEN-LAST:event_btnExchange1ActionPerformed

    private void btnDate1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDate1ActionPerformed

    }//GEN-LAST:event_btnDate1ActionPerformed

    private void cmbFrom2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFrom2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbFrom2ActionPerformed

    private void cmbTo2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbTo2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbTo2ActionPerformed

    private void btnSearch2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearch2ActionPerformed
    
    String from = cmbFrom2.getSelectedItem().toString();
    String to = cmbTo2.getSelectedItem().toString();

    loadSchedulesFromDb(from, to);

    if (tblSchedules.getRowCount() == 0) {
        JOptionPane.showMessageDialog(
                this,
                "No schedule available for this route."
        );
    }
    }//GEN-LAST:event_btnSearch2ActionPerformed

    private void btnExchange2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExchange2ActionPerformed

    String from = cmbFrom2.getSelectedItem().toString();
    String to = cmbTo2.getSelectedItem().toString();

    cmbFrom.setSelectedItem(to);
    cmbTo.setSelectedItem(from);
    }//GEN-LAST:event_btnExchange2ActionPerformed

    private void txtFareActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFareActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFareActionPerformed

    private void btnBookingRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBookingRecordActionPerformed
 BookingRecordFrame booking = new BookingRecordFrame();
        booking.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnBookingRecordActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    SuperFiveFrame frame = new SuperFiveFrame();
        frame.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnContactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnContactActionPerformed
       ViewConcernFeedbackFrame frame = new ViewConcernFeedbackFrame();
        frame.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnContactActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
    AdminDashboard dashboard = new AdminDashboard();
    dashboard.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new UpdateRemoveScheduleFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnBookingRecord;
    private javax.swing.JButton btnContact;
    private javax.swing.JButton btnDate1;
    private javax.swing.JButton btnExchange1;
    private javax.swing.JButton btnExchange2;
    private javax.swing.JButton btnHome;
    private javax.swing.JButton btnRemove;
    private javax.swing.JButton btnSchedule;
    private javax.swing.JButton btnSearch1;
    private javax.swing.JButton btnSearch2;
    private javax.swing.JButton btnUpdateSchedule;
    private javax.swing.JComboBox<String> cmbFrom;
    private javax.swing.JComboBox<String> cmbFrom1;
    private javax.swing.JComboBox<String> cmbFrom2;
    private javax.swing.JComboBox<String> cmbTo;
    private javax.swing.JComboBox<String> cmbTo1;
    private javax.swing.JComboBox<String> cmbTo2;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblMessage;
    private javax.swing.JPanel pnlAddRemove;
    private javax.swing.JPanel pnlMain;
    private javax.swing.JPanel pnlMain1;
    private javax.swing.JPanel pnlSidebar;
    private javax.swing.JPanel pnlTop1;
    private javax.swing.JPanel pnlTop2;
    private javax.swing.JTable tblSchedules;
    private javax.swing.JTextField txtBusNo;
    private javax.swing.JTextField txtDepartureTime;
    private javax.swing.JTextField txtFare;
    private javax.swing.JTextField txtTravelDate;
    private javax.swing.JTextField txtTravelDate1;
    // End of variables declaration//GEN-END:variables

    private void cmbFrom1ActionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void txtTravelDate1ActionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void cmbTo1ActionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}