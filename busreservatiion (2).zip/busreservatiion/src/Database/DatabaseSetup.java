package Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

// Mag-create sa database + tables (kung wala pa) ug mag-butang og starting data.
public class DatabaseSetup {

    private static boolean done = false;

    public static void createDatabase() {
        if (done) {
            return;
        }

        // 1. create database
        try (Connection con = DbConnection.getServerConnection();
             Statement st = con.createStatement()) {
            st.executeUpdate("CREATE DATABASE IF NOT EXISTS " + DbConnection.DB_NAME);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        // 2. create tables
        try (Connection con = DbConnection.getConnection();
             Statement st = con.createStatement()) {

            st.executeUpdate("CREATE TABLE IF NOT EXISTS users ("
                    + "user_id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "full_name VARCHAR(100), "
                    + "email VARCHAR(100), "
                    + "username VARCHAR(50) UNIQUE, "
                    + "password VARCHAR(255))");

            // admin (human na sa ALTER TABLE ... DROP COLUMN full-name)
            st.executeUpdate("CREATE TABLE IF NOT EXISTS admin ("
                    + "admin_id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "username VARCHAR(50), "
                    + "password VARCHAR(255))");

            st.executeUpdate("CREATE TABLE IF NOT EXISTS passenger ("
                    + "passenger_id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "user_id INT, "
                    + "first_name VARCHAR(50), "
                    + "last_name VARCHAR(50), "
                    + "contact_number VARCHAR(20), "
                    + "email VARCHAR(100), "
                    + "discount_type VARCHAR(20), "
                    + "id_number VARCHAR(50))");

            st.executeUpdate("CREATE TABLE IF NOT EXISTS schedule ("
                    + "schedule_id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "trip_code VARCHAR(20), "
                    + "bus_no VARCHAR(20), "
                    + "origin VARCHAR(50), "
                    + "destination VARCHAR(50), "
                    + "travel_date DATE, "
                    + "departure_time VARCHAR(20), "
                    + "fare DECIMAL(10,2))");

            st.executeUpdate("CREATE TABLE IF NOT EXISTS seat ("
                    + "seat_id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "schedule_id INT, "
                    + "seat_number INT, "
                    + "status VARCHAR(20), "
                    + "FOREIGN KEY (schedule_id) REFERENCES schedule(schedule_id))");

            st.executeUpdate("CREATE TABLE IF NOT EXISTS booking ("
                    + "booking_id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "passenger_id INT, "
                    + "schedule_id INT, "
                    + "seat_id INT, "
                    + "original_booking_id INT, "
                    + "booking_date DATETIME, "
                    + "total_fare DECIMAL(10,2), "
                    + "status VARCHAR(20), "
                    + "FOREIGN KEY (passenger_id) REFERENCES passenger(passenger_id), "
                    + "FOREIGN KEY (schedule_id) REFERENCES schedule(schedule_id), "
                    + "FOREIGN KEY (seat_id) REFERENCES seat(seat_id), "
                    + "FOREIGN KEY (original_booking_id) REFERENCES booking(booking_id))");

            st.executeUpdate("CREATE TABLE IF NOT EXISTS payment ("
                    + "payment_id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "booking_id INT, "
                    + "amount DECIMAL(10,2), "
                    + "payment_method VARCHAR(50), "
                    + "payment_status VARCHAR(20), "
                    + "transaction_date DATETIME, "
                    + "reference_no VARCHAR(50), "
                    + "total_fare DECIMAL(10,2), "
                    + "status VARCHAR(20), "
                    + "FOREIGN KEY (booking_id) REFERENCES booking(booking_id))");

            st.executeUpdate("CREATE TABLE IF NOT EXISTS schedule_seed ("
                    + "seed_date DATE PRIMARY KEY)");

            // 3. starting data
            seedAdmin(con);
            seedSchedules(con);

            done = true;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // default admin account: admin / admin123
    private static void seedAdmin(Connection con) throws Exception {
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM admin")) {
            rs.next();
            if (rs.getInt(1) > 0) {
                return;
            }
        }
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO admin (username, password) VALUES (?, ?)")) {
            ps.setString(1, "admin");
            ps.setString(2, "admin123");
            ps.executeUpdate();
        }
    }

    // Pwede tawgon sa bisan asa: siguroha nga naay schedules para sa sunod 8 ka adlaw
    public static void seedUpcoming() {
        try (Connection con = DbConnection.getConnection()) {
            if (con != null) {
                seedSchedules(con);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Siguroha nga na-seed ang usa ka petsa ("MM/dd/yyyy") - gitawag pag-search sa dashboard
    public static void seedDate(String dateText) {
        try (Connection con = DbConnection.getConnection()) {
            if (con == null) {
                return;
            }
            LocalDate date = LocalDate.parse(dateText.trim(), DateTimeFormatter.ofPattern("MM/dd/yyyy"));
            con.setAutoCommit(false);
            try {
                seedDay(con, date);
            } catch (Exception e) {
                con.rollback();
                throw e;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Sunod 8 ka adlaw
    private static void seedSchedules(Connection con) throws Exception {
        cleanupOldData(con);
        boolean oldAuto = con.getAutoCommit();
        con.setAutoCommit(false);
        try {
            for (int day = 0; day < 8; day++) {
                seedDay(con, LocalDate.now().plusDays(day));
            }
        } catch (Exception e) {
            con.rollback();
            throw e;
        } finally {
            con.setAutoCommit(oldAuto);
        }
    }

    // Maghimo og schedules (7 routes x 2 direction x 4 ka oras) para sa usa ka adlaw.
    // Kung na-seed na ang adlaw (naa sa schedule_seed), dili na balikon.
    private static void seedDay(Connection con, LocalDate date) throws Exception {
        String[] destinations = {"Wao", "Dipolog", "Pagadian", "Maramag", "Tubod", "Kibawe", "Ozamiz"};
        int[] fares = {350, 550, 450, 300, 400, 350, 500};
        String[] times = {"8:00 AM", "10:00 AM", "1:00 PM", "4:00 PM"};

        String dateText = date.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        java.sql.Date sqlDate = java.sql.Date.valueOf(date);

        try (PreparedStatement ps = con.prepareStatement(
                "SELECT COUNT(*) FROM schedule_seed WHERE seed_date = ?")) {
            ps.setDate(1, sqlDate);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                if (rs.getInt(1) > 0) {
                    return;
                }
            }
        }

        // 28 ka schedules matag adlaw: CDO ngadto sa 7 ka destination x 4 ka oras
        int number = 1;
        for (int d = 0; d < destinations.length; d++) {

            boolean exists;
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT COUNT(*) FROM schedule WHERE origin = 'CDO' "
                    + "AND destination = ? AND travel_date = ?")) {
                ps.setString(1, destinations[d]);
                ps.setDate(2, sqlDate);
                try (ResultSet rs = ps.executeQuery()) {
                    rs.next();
                    exists = rs.getInt(1) > 0;
                }
            }

            if (!exists) {
                for (int t = 0; t < times.length; t++) {
                    ScheduleDB.createSchedule(con, "SF" + (number + t), "CDO",
                            destinations[d], dateText, times[t], fares[d]);
                }
            }
            number += 4;
        }

        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO schedule_seed (seed_date) VALUES (?)")) {
            ps.setDate(1, sqlDate);
            ps.executeUpdate();
        }
        con.commit();
    }

    // Usa ra ka higayon: tangtangon ang sobra nga schedules (dili CDO ang origin, walay booking)
    // ug ibalik ang Ozamiz sa PHP 500.
    private static void cleanupOldData(Connection con) throws Exception {
        java.sql.Date marker = java.sql.Date.valueOf("2000-01-01");

        try (PreparedStatement ps = con.prepareStatement(
                "SELECT COUNT(*) FROM schedule_seed WHERE seed_date = ?")) {
            ps.setDate(1, marker);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                if (rs.getInt(1) > 0) {
                    return;
                }
            }
        }

        try (Statement st = con.createStatement()) {
            st.executeUpdate("DELETE FROM seat WHERE schedule_id IN ("
                    + "SELECT schedule_id FROM (SELECT schedule_id FROM schedule WHERE origin <> 'CDO' "
                    + "AND schedule_id NOT IN (SELECT schedule_id FROM booking)) x)");
            st.executeUpdate("DELETE FROM schedule WHERE origin <> 'CDO' "
                    + "AND schedule_id NOT IN (SELECT schedule_id FROM booking)");
            st.executeUpdate("UPDATE schedule SET fare = 500 "
                    + "WHERE origin = 'CDO' AND destination = 'Ozamiz' AND fare = 300");
        }

        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO schedule_seed (seed_date) VALUES (?)")) {
            ps.setDate(1, marker);
            ps.executeUpdate();
        }
    }
}
