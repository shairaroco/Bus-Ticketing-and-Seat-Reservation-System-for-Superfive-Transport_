
    package Database;

    import java.io.File;
    import java.nio.file.Files;
    import java.nio.file.StandardCopyOption;
    import java.sql.Connection;
    import java.sql.PreparedStatement;

    public class ReceiptDB {

        public static boolean uploadReceipt(
                String referenceNo, File picture) throws Exception {

            File folder = new File("receipts");

            if (!folder.exists() && !folder.mkdirs()) {
                throw new Exception("Cannot create receipts folder.");
            }

            String fileName = "receipt_"
                    + System.currentTimeMillis()
                    + "_" + picture.getName();

            File savedPicture = new File(folder, fileName);
            
            Files.copy(
                    picture.toPath(),
                    savedPicture.toPath(),
                    StandardCopyOption.REPLACE_EXISTING
            );

            String sql = "UPDATE payment SET receipt_path = ? "
                    + "WHERE reference_no = ?";

            try (Connection con = DbConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, savedPicture.getAbsolutePath());
                ps.setString(2, referenceNo);

                int updated = ps.executeUpdate();

                if (updated > 0) {
                    return true;
                }

                Files.deleteIfExists(savedPicture.toPath());
                return false;
            }
        }
    }
