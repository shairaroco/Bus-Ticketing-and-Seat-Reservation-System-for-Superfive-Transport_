
package Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class BookingDB {

    // Save passenger, booking, and payment
    public static String saveBooking(
            int userId, int scheduleId, String from, String to,
            String travelDate, String time, String tripCode,
            int farePerSeat, double grandTotal, String paymentMethod,
            String referenceNo, String contact, String email,
            ArrayList<String> firstNames, ArrayList<String> lastNames,
            ArrayList<String> discountTypes, ArrayList<String> ids,
            ArrayList<Integer> seats) {

        Connection con = null;

        try {
            con = DbConnection.getConnection();

            if (con == null) {
                return "Cannot connect to database.";
            }

            con.setAutoCommit(false);

            if (scheduleId <= 0) {
                scheduleId = ScheduleDB.getOrCreateScheduleId(
                        con, tripCode, from, to, travelDate, time, farePerSeat);
            }

            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT fare FROM schedule WHERE schedule_id = ?")) {

                ps.setInt(1, scheduleId);

                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        con.rollback();
                        return "Schedule not found. Please search again.";
                    }

                    farePerSeat = rs.getInt("fare");
                }
            }

            if (seats == null || seats.isEmpty()) {
                con.rollback();
                return "Please select at least one seat.";
            }

            if (firstNames == null || lastNames == null
                    || discountTypes == null || ids == null
                    || firstNames.size() < seats.size()
                    || lastNames.size() < seats.size()
                    || discountTypes.size() < seats.size()
                    || ids.size() < seats.size()) {

                con.rollback();
                return "Passenger information is incomplete.";
            }

            double amountEach = grandTotal / seats.size();

            for (int i = 0; i < seats.size(); i++) {

                // 1. Save passenger
                int passengerId;

                String passengerSQL =
                        "INSERT INTO passenger "
                        + "(user_id, first_name, last_name, contact_number, "
                        + "email, discount_type, id_number) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?)";

                try (PreparedStatement ps = con.prepareStatement(
                        passengerSQL, Statement.RETURN_GENERATED_KEYS)) {

                    ps.setInt(1, userId);
                    ps.setString(2, firstNames.get(i));
                    ps.setString(3, lastNames.get(i));
                    ps.setString(4, contact);
                    ps.setString(5, email);
                    ps.setString(6, discountTypes.get(i));
                    ps.setString(7, ids.get(i));

                    ps.executeUpdate();

                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) {
                            con.rollback();
                            return "Could not save passenger.";
                        }

                        passengerId = keys.getInt(1);
                    }
                }

                // 2. Check seat availability
                int seatId = -1;

                String seatSQL =
                        "SELECT seat_id, status FROM seat "
                        + "WHERE schedule_id = ? AND seat_number = ? "
                        + "FOR UPDATE";

                try (PreparedStatement ps = con.prepareStatement(seatSQL)) {

                    ps.setInt(1, scheduleId);
                    ps.setInt(2, seats.get(i));

                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            if (!"AVAILABLE".equalsIgnoreCase(
                                    rs.getString("status"))) {

                                con.rollback();
                                return "Seat " + seats.get(i)
                                        + " is already taken.";
                            }

                            seatId = rs.getInt("seat_id");
                        }
                    }
                }

                if (seatId == -1) {
                    con.rollback();
                    return "Seat " + seats.get(i) + " was not found.";
                }

                // 3. Mark seat as booked
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE seat SET status = 'BOOKED' "
                        + "WHERE seat_id = ? AND status = 'AVAILABLE'")) {

                    ps.setInt(1, seatId);

                    if (ps.executeUpdate() != 1) {
                        con.rollback();
                        return "Seat " + seats.get(i)
                                + " is already taken.";
                    }
                }

                // 4. Save booking
                int bookingId;

                String bookingSQL =
                        "INSERT INTO booking "
                        + "(passenger_id, schedule_id, seat_id, "
                        + "original_booking_id, booking_date, total_fare, status) "
                        + "VALUES (?, ?, ?, NULL, NOW(), ?, 'PENDING')";

                try (PreparedStatement ps = con.prepareStatement(
                        bookingSQL, Statement.RETURN_GENERATED_KEYS)) {

                    ps.setInt(1, passengerId);
                    ps.setInt(2, scheduleId);
                    ps.setInt(3, seatId);
                    ps.setInt(4, farePerSeat);

                    ps.executeUpdate();

                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) {
                            con.rollback();
                            return "Could not save booking.";
                        }

                        bookingId = keys.getInt(1);
                    }
                }

                // 5. Save payment
                String paymentSQL =
                        "INSERT INTO payment "
                        + "(booking_id, amount, payment_method, payment_status, "
                        + "transaction_date, reference_no, total_fare, status) "
                        + "VALUES (?, ?, ?, 'PENDING', NOW(), ?, ?, 'PENDING')";

                try (PreparedStatement ps = con.prepareStatement(paymentSQL)) {

                    ps.setInt(1, bookingId);
                    ps.setDouble(2, amountEach);
                    ps.setString(3, paymentMethod);
                    ps.setString(4, referenceNo);
                    ps.setInt(5, farePerSeat);

                    ps.executeUpdate();
                }
            }

            con.commit();
            return null;

        } catch (Exception e) {
            e.printStackTrace();

            try {
                if (con != null) {
                    con.rollback();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            return "Database error: " + e.getMessage();

        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // Get bookings for admin table
   
public static ArrayList<Object[]> getBookings(String from, String to) {

    ArrayList<Object[]> rows = new ArrayList<>();

    String sql = "SELECT b.booking_id, "
            + "CONCAT(p.first_name, ' ', p.last_name) AS pname, "
            + "s.origin, s.destination, "
            + "DATE_FORMAT(s.travel_date, '%m/%d/%Y') AS tdate, "
            + "pay.reference_no, b.status "
            + "FROM booking b "
            + "JOIN passenger p ON b.passenger_id = p.passenger_id "
            + "JOIN schedule s ON b.schedule_id = s.schedule_id "
            + "LEFT JOIN payment pay ON b.booking_id = pay.booking_id ";

    if (from != null && to != null) {
        sql += "WHERE s.origin = ? AND s.destination = ? ";
    }

    sql += "ORDER BY b.booking_id DESC";

    try {
        java.sql.Connection con = DbConnection.getConnection();
        java.sql.PreparedStatement ps = con.prepareStatement(sql);

        if (from != null && to != null) {
            ps.setString(1, from);
            ps.setString(2, to);
        }

        java.sql.ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            rows.add(new Object[]{
                rs.getInt("booking_id"),
                rs.getString("pname"),
                rs.getString("origin"),
                rs.getString("destination"),
                rs.getString("tdate"),
                rs.getString("reference_no"),
                rs.getString("status")
            });
        }

        rs.close();
        ps.close();
        con.close();

    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(
                null, "Error loading bookings: " + e.getMessage());
    }

    return rows;
}

    // Accept booking and update both tables
    public static boolean acceptBooking(int bookingId) {

        Connection con = null;

        try {
            con = DbConnection.getConnection();

            if (con == null) {
                return false;
            }

            con.setAutoCommit(false);

            String bookingSQL =
                    "UPDATE booking SET status = 'APPROVED' "
                    + "WHERE booking_id = ? AND status = 'PENDING'";

            int bookingUpdated;

            try (PreparedStatement ps = con.prepareStatement(bookingSQL)) {
                ps.setInt(1, bookingId);
                bookingUpdated = ps.executeUpdate();
            }

            if (bookingUpdated == 0) {
                con.rollback();
                return false;
            }

            String paymentSQL =
                    "UPDATE payment "
                    + "SET payment_status = 'APPROVED', status = 'APPROVED' "
                    + "WHERE booking_id = ? AND payment_status = 'PENDING'";

            int paymentUpdated;

            try (PreparedStatement ps = con.prepareStatement(paymentSQL)) {
                ps.setInt(1, bookingId);
                paymentUpdated = ps.executeUpdate();
            }

            if (paymentUpdated == 0) {
                con.rollback();
                return false;
            }

            con.commit();
            return true;

        } catch (Exception e) {
            e.printStackTrace();

            try {
                if (con != null) {
                    con.rollback();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            return false;

        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // Decline booking and update both tables
    public static boolean declineBooking(int bookingId) {

        Connection con = null;

        try {
            con = DbConnection.getConnection();

            if (con == null) {
                return false;
            }

            con.setAutoCommit(false);

            String bookingSQL =
                    "UPDATE booking SET status = 'DECLINED' "
                    + "WHERE booking_id = ? AND status = 'PENDING'";

            int bookingUpdated;

            try (PreparedStatement ps = con.prepareStatement(bookingSQL)) {
                ps.setInt(1, bookingId);
                bookingUpdated = ps.executeUpdate();
            }

            if (bookingUpdated == 0) {
                con.rollback();
                return false;
            }

            String paymentSQL =
                    "UPDATE payment "
                    + "SET payment_status = 'DECLINED', status = 'DECLINED' "
                    + "WHERE booking_id = ? AND payment_status = 'PENDING'";

            int paymentUpdated;

            try (PreparedStatement ps = con.prepareStatement(paymentSQL)) {
                ps.setInt(1, bookingId);
                paymentUpdated = ps.executeUpdate();
            }

            if (paymentUpdated == 0) {
                con.rollback();
                return false;
            }

            con.commit();
            return true;

        } catch (Exception e) {
            e.printStackTrace();

            try {
                if (con != null) {
                    con.rollback();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            return false;

        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // Get passenger bookings
    public static ArrayList<Object[]> getUserBookings(int userId) {

        ArrayList<Object[]> rows = new ArrayList<>();

        String sql =
                "SELECT b.booking_id, "
                + "CONCAT(s.origin, ' to ', s.destination) AS route, "
                + "DATE_FORMAT(s.travel_date, '%m/%d/%Y') AS tdate, "
                + "st.seat_number, b.total_fare "
                + "FROM booking b "
                + "JOIN passenger p ON b.passenger_id = p.passenger_id "
                + "JOIN schedule s ON b.schedule_id = s.schedule_id "
                + "JOIN seat st ON b.seat_id = st.seat_id "
                + "WHERE p.user_id = ? ORDER BY b.booking_id DESC";

        try (Connection con = DbConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, userId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(new Object[]{
                        rs.getInt("booking_id"),
                        rs.getString("route"),
                        rs.getString("tdate"),
                        rs.getInt("seat_number"),
                        "PHP " + rs.getInt("total_fare")
                    });
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows;
    }

    // Get booking and payment status for passenger
    public static ArrayList<Object[]> getUserStatus(int userId) {

        ArrayList<Object[]> rows = new ArrayList<>();

        String sql =
                "SELECT b.booking_id, b.status, "
                + "pay.payment_status, pay.reference_no "
                + "FROM booking b "
                + "JOIN passenger p ON b.passenger_id = p.passenger_id "
                + "LEFT JOIN payment pay ON pay.booking_id = b.booking_id "
                + "WHERE p.user_id = ? ORDER BY b.booking_id DESC";

        try (Connection con = DbConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, userId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(new Object[]{
                        rs.getInt("booking_id"),
                        rs.getString("status"),
                        rs.getString("payment_status"),
                        rs.getString("reference_no")
                    });
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows;
    }
}
