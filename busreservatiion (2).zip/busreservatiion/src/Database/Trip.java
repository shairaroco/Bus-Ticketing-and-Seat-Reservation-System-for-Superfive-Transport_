package Database;

// Usa ka biyahe (schedule) nga ipakita sa passenger dashboard
public class Trip {

    public int scheduleId;
    public String tripCode;
    public String busNo;
    public String time;
    public int fare;
    public int seatsLeft;
}
