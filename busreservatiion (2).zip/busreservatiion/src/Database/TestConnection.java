package Database;

import java.sql.Connection;

public class TestConnection {

    public static void main(String[] args) {
        DatabaseSetup.createDatabase();
        Connection con = DbConnection.getConnection();
        if (con != null) {
            System.out.println("Connected to database: " + DbConnection.DB_NAME);
        } else {
            System.out.println("Connection FAILED. Check MySQL and the connector jar.");
        }
    }
}
