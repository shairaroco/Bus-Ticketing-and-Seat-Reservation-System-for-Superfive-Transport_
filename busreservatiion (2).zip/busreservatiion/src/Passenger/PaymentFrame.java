package Passenger;


import java.awt.Font;
import javax.swing.JLabel;
import java.util.ArrayList;

public class PaymentFrame extends javax.swing.JFrame {
    
     private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PaymentFrame.class.getName());
     
    String from;
    String to;
    String travelDate;
    String tripTime;
    String pickupTime;
    String tripCode;
    String busType;
    
    double grandTotal;
    int farePerSeat;
    int selectedSeatCount;
    int totalFare;
    int discountedPassengerCount = 0;
    
    ArrayList<String> passengerNames =
            new ArrayList<>();
    
    ArrayList<Integer> seats =
            new ArrayList<>();

    ArrayList<String> firstNames = new ArrayList<>();
    ArrayList<String> lastNames = new ArrayList<>();
    ArrayList<String> ids = new ArrayList<>();
    ArrayList<String> discountTypes = new ArrayList<>();
    String contactNumber = "";
    String email = "";

    public String paymentMethod;

    
    public void loadPayment() {

    int linersFee = 20;
    int insurance = 20;
    int serviceFee = 50;
    int discount = 0;

    selectedSeatCount = seats.size();

    totalFare = farePerSeat * selectedSeatCount;

    int grandTotal = totalFare
            + linersFee
            + insurance
            + serviceFee
            - discount;

    lblFarePerSeat.setText("₱" + farePerSeat);
    lblTotalFare.setText("₱" + totalFare);
    lblLinersFee.setText("₱" + linersFee);
    lblInsurance.setText("₱" + insurance);
    lblDiscount.setText("₱" + discount);
    lblServiceFee.setText("₱" + serviceFee);
    lblNoPax.setText("" + selectedSeatCount);
    lblGrandTotal.setText("₱" + grandTotal);

}
    public PaymentFrame() {
        initComponents();   
       
    }

  private void setFare() {

    if ((from.equals("CDO") && to.equals("Wao"))
            || (from.equals("Wao") && to.equals("CDO"))) {

        farePerSeat = 350;

    } else if ((from.equals("CDO") && to.equals("Dipolog"))
            || (from.equals("Dipolog") && to.equals("CDO"))) {

        farePerSeat = 550;

    } else if ((from.equals("CDO") && to.equals("Pagadian"))
            || (from.equals("Pagadian") && to.equals("CDO"))) {

        farePerSeat = 450;

    } else if ((from.equals("CDO") && to.equals("Maramag"))
            || (from.equals("Maramag") && to.equals("CDO"))) {

        farePerSeat = 300;

    } else if ((from.equals("CDO") && to.equals("Tubod"))
            || (from.equals("Tubod") && to.equals("CDO"))) {

        farePerSeat = 400;

    } else if ((from.equals("CDO") && to.equals("Kibawe"))
            || (from.equals("Kibawe") && to.equals("CDO"))) {

        farePerSeat = 350;

    } else if ((from.equals("CDO") && to.equals("Ozamiz"))
            || (from.equals("Ozamiz") && to.equals("CDO"))) {

        farePerSeat = 300;
    }
}
public void loadPaymentDetails() {


    int linerFee = 20;
    int insurance = 20;
    int serviceFee = 50;
    int discount = 0;

    totalFare = farePerSeat * selectedSeatCount;

    grandTotal = totalFare
            + linerFee
            + insurance
            + serviceFee
            - discount;

    lblFarePerSeat.setText(
            String.format("PHP %.2f", (double) farePerSeat)
    );

    lblTotalFare.setText(
            String.format("PHP %.2f", (double) totalFare)
    );

    lblLinersFee.setText(
            String.format("PHP %.2f", (double) linerFee)
    );

    lblInsurance.setText(
            String.format("PHP %.2f", (double) insurance)
    );

    lblDiscount.setText(
            String.format("PHP %.2f", (double) discount)
    );

    lblServiceFee.setText(
            String.format("PHP %.2f", (double) serviceFee)
    );

    lblNoPax.setText("" + selectedSeatCount);

    lblTotal.setText(
            String.format("PHP %.2f", grandTotal));
    
    lblTotalPayment.setText(String.format("PHP %.2f", grandTotal));
    
}
public void loadPassengerDetails() {

    pnlPassenger.removeAll();

    pnlPassenger.setLayout(
        new java.awt.GridLayout(0, 2, 20, 10)
    );

    for (int i = 0; i < passengerNames.size(); i++) {

        JLabel seatLabel = new JLabel(
            "Seat " + seats.get(i)
        );

        JLabel nameLabel = new JLabel(
            passengerNames.get(i)
        );

        seatLabel.setFont(
            new Font("Arial", Font.BOLD, 14)
        );

        nameLabel.setFont(
            new Font("Arial", Font.BOLD, 14)
        );

        pnlPassenger.add(seatLabel);
        pnlPassenger.add(nameLabel);
    }

    pnlPassenger.revalidate();
    pnlPassenger.repaint();
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        PaymentFrame = new javax.swing.JPanel();
        txtPromoCode = new javax.swing.JTextField();
        btnApply = new javax.swing.JButton();
        lblPayment = new javax.swing.JLabel();
        btnGcash = new javax.swing.JButton();
        btnMaya = new javax.swing.JButton();
        pnlPaymentInfo = new javax.swing.JPanel();
        lblTotalPayment = new javax.swing.JLabel();
        lblTotalAmount = new javax.swing.JLabel();
        pnlBookingReminders = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        pnlBookingSummary = new javax.swing.JPanel();
        lblBookingSummary = new javax.swing.JLabel();
        lblSummaryDescriptions = new javax.swing.JLabel();
        pnlPassenger = new javax.swing.JPanel();
        lblSeatNumber = new javax.swing.JLabel();
        lblPassengerName = new javax.swing.JLabel();
        pnlPaymentDetails = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        lblTotalFareTitle = new javax.swing.JLabel();
        lblLinersFareTitle = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        lblDiscountTitle = new javax.swing.JLabel();
        lblServiceFeeTitle = new javax.swing.JLabel();
        lblNoOfPaxTitle = new javax.swing.JLabel();
        lblFarePerSeat = new javax.swing.JLabel();
        lblTotalFare = new javax.swing.JLabel();
        lblLinersFee = new javax.swing.JLabel();
        lblInsurance = new javax.swing.JLabel();
        lblDiscount = new javax.swing.JLabel();
        lblServiceFee = new javax.swing.JLabel();
        lblServiceFeeTitle1 = new javax.swing.JLabel();
        lblNoPax = new javax.swing.JLabel();
        lblGrandTotal = new javax.swing.JLabel();
        lblTotal = new javax.swing.JLabel();
        lblGrandTotal1 = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnPassengerDetails = new javax.swing.JToggleButton();
        btnPaymentDetails = new javax.swing.JToggleButton();
        lbl = new javax.swing.JLabel();
        lblMessage = new javax.swing.JLabel();
        btnCreditDebitCard = new javax.swing.JButton();

        jLabel7.setText("jLabel7");

        jLabel10.setBackground(new java.awt.Color(250, 248, 227));
        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(250, 248, 227));
        jLabel10.setText("SUPER FIVE");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        PaymentFrame.setBackground(new java.awt.Color(30, 105, 75));

        txtPromoCode.setText("Enter Promo Code");

        btnApply.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnApply.setText("APPLY");
        btnApply.addActionListener(this::btnApplyActionPerformed);

        lblPayment.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblPayment.setForeground(new java.awt.Color(255, 255, 255));
        lblPayment.setText("SELECT PAYMENT METHOD");

        btnGcash.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnGcash.setText("Gcash/ GCredit");
        btnGcash.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnGcash.addActionListener(this::btnGcashActionPerformed);

        btnMaya.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnMaya.setText(" Maya");
        btnMaya.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnMaya.addActionListener(this::btnMayaActionPerformed);

        pnlPaymentInfo.setBackground(new java.awt.Color(255, 255, 255));

        lblTotalPayment.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        lblTotalAmount.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTotalAmount.setText("Total Payment:");

        javax.swing.GroupLayout pnlPaymentInfoLayout = new javax.swing.GroupLayout(pnlPaymentInfo);
        pnlPaymentInfo.setLayout(pnlPaymentInfoLayout);
        pnlPaymentInfoLayout.setHorizontalGroup(
            pnlPaymentInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPaymentInfoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTotalAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblTotalPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37))
        );
        pnlPaymentInfoLayout.setVerticalGroup(
            pnlPaymentInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlPaymentInfoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlPaymentInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblTotalPayment, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(pnlPaymentInfoLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblTotalAmount)))
                .addGap(53, 53, 53))
        );

        pnlBookingReminders.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("BOOKING REMINDERS:");

        jLabel3.setText("• Don't forget to download your ticket voucher after payment. ");

        jLabel4.setText("• Retrieve your ticket voucher after booking. ");

        jLabel5.setText("• If you don't receive any confirmation, contact support.");

        javax.swing.GroupLayout pnlBookingRemindersLayout = new javax.swing.GroupLayout(pnlBookingReminders);
        pnlBookingReminders.setLayout(pnlBookingRemindersLayout);
        pnlBookingRemindersLayout.setHorizontalGroup(
            pnlBookingRemindersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBookingRemindersLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlBookingRemindersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlBookingRemindersLayout.setVerticalGroup(
            pnlBookingRemindersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBookingRemindersLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addContainerGap(11, Short.MAX_VALUE))
        );

        pnlBookingSummary.setBackground(new java.awt.Color(250, 248, 227));

        lblBookingSummary.setBackground(new java.awt.Color(0, 0, 0));
        lblBookingSummary.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblBookingSummary.setForeground(new java.awt.Color(30, 105, 75));
        lblBookingSummary.setText("BOOKING SUMMARY");

        lblSummaryDescriptions.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        lblSummaryDescriptions.setText("Review your booking details before proceeding to payment");

        pnlPassenger.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout pnlPassengerLayout = new javax.swing.GroupLayout(pnlPassenger);
        pnlPassenger.setLayout(pnlPassengerLayout);
        pnlPassengerLayout.setHorizontalGroup(
            pnlPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPassengerLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(lblSeatNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(91, 91, 91)
                .addComponent(lblPassengerName, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlPassengerLayout.setVerticalGroup(
            pnlPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPassengerLayout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(pnlPassengerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPassengerName, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblSeatNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(172, Short.MAX_VALUE))
        );

        pnlPaymentDetails.setBackground(new java.awt.Color(204, 204, 204));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Fare Per Seat:");

        lblTotalFareTitle.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblTotalFareTitle.setText("Total Fare:");

        lblLinersFareTitle.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblLinersFareTitle.setText("Liners Fee:");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel11.setText("Insurance:");

        lblDiscountTitle.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblDiscountTitle.setText("Discount:");

        lblServiceFeeTitle.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblServiceFeeTitle.setText("Service Fee:");

        lblNoOfPaxTitle.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblNoOfPaxTitle.setText("No. of Pax");

        lblFarePerSeat.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblFarePerSeat.setText("1");
        lblFarePerSeat.setPreferredSize(new java.awt.Dimension(17, 0));

        lblTotalFare.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblTotalFare.setText("1");

        lblLinersFee.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblLinersFee.setText("1");

        lblInsurance.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblInsurance.setText("1");

        lblDiscount.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblDiscount.setText("1");

        lblServiceFee.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblServiceFee.setText("1");

        lblServiceFeeTitle1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblServiceFeeTitle1.setText("No. of Pax:");

        lblNoPax.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblNoPax.setText("1");

        lblGrandTotal.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        lblTotal.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblTotal.setText("1");

        lblGrandTotal1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblGrandTotal1.setText("Total");

        javax.swing.GroupLayout pnlPaymentDetailsLayout = new javax.swing.GroupLayout(pnlPaymentDetails);
        pnlPaymentDetails.setLayout(pnlPaymentDetailsLayout);
        pnlPaymentDetailsLayout.setHorizontalGroup(
            pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPaymentDetailsLayout.createSequentialGroup()
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlPaymentDetailsLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(lblNoOfPaxTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlPaymentDetailsLayout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblServiceFeeTitle1, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblTotalFareTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblLinersFareTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblDiscountTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblServiceFeeTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblGrandTotal1, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(132, 132, 132)
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblLinersFee, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblServiceFee, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                        .addComponent(lblDiscount, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblInsurance, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlPaymentDetailsLayout.createSequentialGroup()
                        .addGap(98, 98, 98)
                        .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(lblTotalFare, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(lblFarePerSeat, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lblGrandTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lblTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lblNoPax, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlPaymentDetailsLayout.setVerticalGroup(
            pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPaymentDetailsLayout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(lblFarePerSeat, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTotalFareTitle)
                    .addComponent(lblTotalFare, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblLinersFee, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblLinersFareTitle))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(lblInsurance, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDiscountTitle)
                    .addComponent(lblDiscount))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblServiceFeeTitle)
                    .addComponent(lblServiceFee))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblServiceFeeTitle1)
                    .addComponent(lblNoPax, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblGrandTotal1)
                    .addGroup(pnlPaymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblGrandTotal)
                        .addComponent(lblTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(97, 97, 97)
                .addComponent(lblNoOfPaxTitle))
        );

        btnBack.setBackground(new java.awt.Color(30, 105, 75));
        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.addActionListener(this::btnBackActionPerformed);

        btnNext.setBackground(new java.awt.Color(30, 105, 75));
        btnNext.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnNext.setForeground(new java.awt.Color(255, 255, 255));
        btnNext.setText("NEXT");
        btnNext.addActionListener(this::btnNextActionPerformed);

        btnPassengerDetails.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnPassengerDetails.setForeground(new java.awt.Color(30, 105, 75));
        btnPassengerDetails.setText("PASSENGER DETAILS                             ▼");
        btnPassengerDetails.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnPassengerDetails.addActionListener(this::btnPassengerDetailsActionPerformed);

        btnPaymentDetails.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnPaymentDetails.setForeground(new java.awt.Color(30, 105, 75));
        btnPaymentDetails.setText("PAYMENT DETAILS                                 ▼");
        btnPaymentDetails.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnPaymentDetails.addActionListener(this::btnPaymentDetailsActionPerformed);

        lbl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        javax.swing.GroupLayout pnlBookingSummaryLayout = new javax.swing.GroupLayout(pnlBookingSummary);
        pnlBookingSummary.setLayout(pnlBookingSummaryLayout);
        pnlBookingSummaryLayout.setHorizontalGroup(
            pnlBookingSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBookingSummaryLayout.createSequentialGroup()
                .addContainerGap(36, Short.MAX_VALUE)
                .addGroup(pnlBookingSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(pnlPassenger, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlPaymentDetails, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnPaymentDetails, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnPassengerDetails, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(pnlBookingSummaryLayout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(lblSummaryDescriptions))
                    .addGroup(pnlBookingSummaryLayout.createSequentialGroup()
                        .addGroup(pnlBookingSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlBookingSummaryLayout.createSequentialGroup()
                                .addGap(55, 55, 55)
                                .addComponent(btnBack))
                            .addGroup(pnlBookingSummaryLayout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addComponent(lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(152, 152, 152)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnNext)))
                .addContainerGap(39, Short.MAX_VALUE))
            .addGroup(pnlBookingSummaryLayout.createSequentialGroup()
                .addGap(106, 106, 106)
                .addComponent(lblBookingSummary)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlBookingSummaryLayout.setVerticalGroup(
            pnlBookingSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBookingSummaryLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(lblBookingSummary)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblSummaryDescriptions)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnPassengerDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pnlPassenger, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(btnPaymentDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pnlPaymentDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lbl)
                .addGap(18, 18, 18)
                .addGroup(pnlBookingSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnBack)
                    .addComponent(btnNext))
                .addGap(44, 44, 44))
        );

        lblMessage.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        btnCreditDebitCard.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnCreditDebitCard.setText("GoTyme");
        btnCreditDebitCard.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnCreditDebitCard.addActionListener(this::btnCreditDebitCardActionPerformed);

        javax.swing.GroupLayout PaymentFrameLayout = new javax.swing.GroupLayout(PaymentFrame);
        PaymentFrame.setLayout(PaymentFrameLayout);
        PaymentFrameLayout.setHorizontalGroup(
            PaymentFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PaymentFrameLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PaymentFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlBookingReminders, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnGcash, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(PaymentFrameLayout.createSequentialGroup()
                        .addGroup(PaymentFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(PaymentFrameLayout.createSequentialGroup()
                                .addGroup(PaymentFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(PaymentFrameLayout.createSequentialGroup()
                                        .addComponent(lblPayment)
                                        .addGap(14, 14, 14)))
                                .addGap(68, 68, 68))
                            .addGroup(PaymentFrameLayout.createSequentialGroup()
                                .addComponent(txtPromoCode, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnApply)
                                .addGap(12, 12, 12)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(btnMaya, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlPaymentInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCreditDebitCard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlBookingSummary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        PaymentFrameLayout.setVerticalGroup(
            PaymentFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PaymentFrameLayout.createSequentialGroup()
                .addGap(162, 162, 162)
                .addGroup(PaymentFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnApply, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPromoCode))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblPayment)
                .addGap(18, 18, 18)
                .addComponent(btnGcash)
                .addGap(15, 15, 15)
                .addComponent(btnMaya)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnCreditDebitCard)
                .addGap(18, 18, 18)
                .addComponent(pnlPaymentInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pnlBookingReminders, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(268, 268, 268))
            .addGroup(PaymentFrameLayout.createSequentialGroup()
                .addComponent(pnlBookingSummary, javax.swing.GroupLayout.PREFERRED_SIZE, 739, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PaymentFrame, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PaymentFrame, javax.swing.GroupLayout.PREFERRED_SIZE, 740, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGcashActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGcashActionPerformed
        paymentMethod = "GCash / GCredit";

    btnGcash.setBackground(new java.awt.Color(30,105,75));

    btnMaya.setBackground(java.awt.Color.WHITE);
    btnCreditDebitCard.setBackground(java.awt.Color.WHITE);
    }//GEN-LAST:event_btnGcashActionPerformed

    private void btnApplyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnApplyActionPerformed

    int discount = 0;

    String promoCode = txtPromoCode.getText();

    if (promoCode.equals("BUS10")) {
        discount = 10;

    } else if (promoCode.equals("TRIP20")) {
        discount = 20;

    } else if (promoCode.isEmpty()) {
        lblMessage.setText("Please enter a promo code.");
        return;

    } else {
        lblMessage.setText("Invalid promo code.");
        return;
    }

    int linerFee = 20;
    int insurance = 20;
    int serviceFee = 50;

    grandTotal = totalFare
            + linerFee
            + insurance
            + serviceFee
            - discount;

    lblDiscount.setText("PHP " + discount);

    lblTotal.setText(
            String.format("PHP %.2f", grandTotal)
    );
    
    lblTotalPayment.setText(
        String.format("PHP %.2f", grandTotal)
);
    lblMessage.setText("Promo code applied.");
    }//GEN-LAST:event_btnApplyActionPerformed

    private void btnPaymentDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPaymentDetailsActionPerformed
        if (btnPaymentDetails.isSelected()) {
            pnlPaymentDetails.setVisible(true);
        } else {
            pnlPaymentDetails.setVisible(false);
        }
    }//GEN-LAST:event_btnPaymentDetailsActionPerformed

    private void btnPassengerDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPassengerDetailsActionPerformed
        if (btnPassengerDetails.isSelected()) {
            pnlPassenger.setVisible(true);
        } else {
            pnlPassenger.setVisible(false);
        }
    }//GEN-LAST:event_btnPassengerDetailsActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        if (paymentMethod == null) {
            lbl.setText("Please select a payment method.");
            return;
        }

        GcashFrame gcash = new GcashFrame();
        gcash.totalAmount = grandTotal;
        gcash.paymentMethod = paymentMethod;
        gcash.from = from;
        gcash.to = to;
        gcash.travelDate = travelDate;
        gcash.tripTime = tripTime;
        gcash.pickupTime = pickupTime;
        gcash.tripCode = tripCode;
        gcash.farePerSeat = farePerSeat;
        gcash.totalFare = totalFare;
        gcash.contactNumber = contactNumber;
        gcash.email = email;
        gcash.passengerNames.addAll(passengerNames);
        gcash.seats.addAll(seats);
        gcash.firstNames.addAll(firstNames);
        gcash.lastNames.addAll(lastNames);
        gcash.ids.addAll(ids);
        gcash.discountTypes.addAll(discountTypes);
        gcash.loadAmount();
        gcash.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnMayaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMayaActionPerformed
        paymentMethod = "Maya";

        btnMaya.setBackground(new java.awt.Color(30,105,75));
        btnGcash.setBackground(java.awt.Color.WHITE);
        btnCreditDebitCard.setBackground(java.awt.Color.WHITE);
    }//GEN-LAST:event_btnMayaActionPerformed

    private void btnCreditDebitCardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCreditDebitCardActionPerformed
    paymentMethod = "GoTyme";

        btnCreditDebitCard.setBackground(new java.awt.Color(30,105,75));
        btnGcash.setBackground(java.awt.Color.WHITE);
        btnMaya.setBackground(java.awt.Color.WHITE);    }//GEN-LAST:event_btnCreditDebitCardActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed

    PassengerDetailsFrame passenger = new PassengerDetailsFrame();

    passenger.from = from;
    passenger.to = to;
    passenger.travelDate = travelDate;
    passenger.tripTime = tripTime;
    passenger.pickupTime = pickupTime;
    passenger.tripCode = tripCode;
    passenger.busType = busType;

    passenger.farePerSeat = farePerSeat;
    passenger.selectedSeatCount = selectedSeatCount;
    passenger.totalFare = totalFare;

    passenger.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new PaymentFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PaymentFrame;
    private javax.swing.JButton btnApply;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnCreditDebitCard;
    private javax.swing.JButton btnGcash;
    private javax.swing.JButton btnMaya;
    private javax.swing.JButton btnNext;
    private javax.swing.JToggleButton btnPassengerDetails;
    private javax.swing.JToggleButton btnPaymentDetails;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel lbl;
    private javax.swing.JLabel lblBookingSummary;
    private javax.swing.JLabel lblDiscount;
    private javax.swing.JLabel lblDiscountTitle;
    private javax.swing.JLabel lblFarePerSeat;
    private javax.swing.JLabel lblGrandTotal;
    private javax.swing.JLabel lblGrandTotal1;
    private javax.swing.JLabel lblInsurance;
    private javax.swing.JLabel lblLinersFareTitle;
    private javax.swing.JLabel lblLinersFee;
    private javax.swing.JLabel lblMessage;
    private javax.swing.JLabel lblNoOfPaxTitle;
    private javax.swing.JLabel lblNoPax;
    private javax.swing.JLabel lblPassengerName;
    private javax.swing.JLabel lblPayment;
    private javax.swing.JLabel lblSeatNumber;
    private javax.swing.JLabel lblServiceFee;
    private javax.swing.JLabel lblServiceFeeTitle;
    private javax.swing.JLabel lblServiceFeeTitle1;
    private javax.swing.JLabel lblSummaryDescriptions;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JLabel lblTotalAmount;
    private javax.swing.JLabel lblTotalFare;
    private javax.swing.JLabel lblTotalFareTitle;
    private javax.swing.JLabel lblTotalPayment;
    private javax.swing.JPanel pnlBookingReminders;
    private javax.swing.JPanel pnlBookingSummary;
    private javax.swing.JPanel pnlPassenger;
    private javax.swing.JPanel pnlPaymentDetails;
    private javax.swing.JPanel pnlPaymentInfo;
    private javax.swing.JTextField txtPromoCode;
    // End of variables declaration//GEN-END:variables
}
