package Passenger;

import javax.swing.JOptionPane;
import java.util.ArrayList;


public class ShowButtonFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ShowButtonFrame.class.getName());

    public String selectedSeats;
    public String from;
    public String to;
    public String travelDate;
    public String tripTime;
    public String busType;
    String tripCode;
    String pickupTime;
    
    int farePerSeat = 0;
    int selectedSeatCount = 0;
    int totalFare = 0;
    
    public ShowButtonFrame() {
        initComponents();
        SeatManager.selectedSeats.clear();
        
        lblFarePerSeat1.setVisible(true);
        lblSeatsSelected1.setVisible(true);
        lblTotalFare1.setVisible(true);

        btnSeats1.setBackground(java.awt.Color.WHITE);
        btnSeats2.setBackground(java.awt.Color.WHITE);
        btnSeats3.setBackground(java.awt.Color.WHITE);
        btnSeats4.setBackground(java.awt.Color.WHITE);
        btnSeats5.setBackground(java.awt.Color.WHITE);
        btnSeats6.setBackground(java.awt.Color.WHITE);
        btnSeats7.setBackground(java.awt.Color.WHITE);
        btnSeats8.setBackground(java.awt.Color.WHITE);
        btnSeats9.setBackground(java.awt.Color.WHITE);
        btnSeats10.setBackground(java.awt.Color.WHITE);
        btnSeats11.setBackground(java.awt.Color.WHITE);
        btnSeats12.setBackground(java.awt.Color.WHITE);
        btnSeats13.setBackground(java.awt.Color.WHITE);
        btnSeats14.setBackground(java.awt.Color.WHITE);
        btnSeats15.setBackground(java.awt.Color.WHITE);
        btnSeats16.setBackground(java.awt.Color.WHITE);
        btnSeats17.setBackground(java.awt.Color.WHITE);
        btnSeats18.setBackground(java.awt.Color.WHITE);
        btnSeats19.setBackground(java.awt.Color.WHITE);
        btnSeats20.setBackground(java.awt.Color.WHITE);
        btnSeats21.setBackground(java.awt.Color.WHITE);
        btnSeats22.setBackground(java.awt.Color.WHITE);
        btnSeats23.setBackground(java.awt.Color.WHITE);
        btnSeats24.setBackground(java.awt.Color.WHITE);
        btnSeats25.setBackground(java.awt.Color.WHITE);
        btnSeats26.setBackground(java.awt.Color.WHITE);
        btnSeats27.setBackground(java.awt.Color.WHITE);
        btnSeats28.setBackground(java.awt.Color.WHITE);
        btnSeats29.setBackground(java.awt.Color.WHITE);
        btnSeats30.setBackground(java.awt.Color.WHITE);
        btnSeats31.setBackground(java.awt.Color.WHITE);
        btnSeats32.setBackground(java.awt.Color.WHITE);
        btnSeats33.setBackground(java.awt.Color.WHITE);
        btnSeats34.setBackground(java.awt.Color.WHITE);
        btnSeats35.setBackground(java.awt.Color.WHITE);
        btnSeats36.setBackground(java.awt.Color.WHITE);
        btnSeats37.setBackground(java.awt.Color.WHITE);
        btnSeats38.setBackground(java.awt.Color.WHITE);
        btnSeats39.setBackground(java.awt.Color.WHITE);
        btnSeats40.setBackground(java.awt.Color.WHITE);
        btnSeats41.setBackground(java.awt.Color.WHITE);
        btnSeats42.setBackground(java.awt.Color.WHITE);
        btnSeats43.setBackground(java.awt.Color.WHITE);
        btnSeats44.setBackground(java.awt.Color.WHITE);

        lblSelectedSeats.setText("");
        FarePerSeat.setText("");
        lblTotalFare.setText("");
    }

    public void loadRoute() {
        RouteData.setRoute(cmbPickup, cmbDropoff, from, to);
        setFare(from, to);
         lblPickupTime.setText(pickupTime);
        lblTripCode.setText(tripCode);

        // gamita ang fare gikan sa database (kung naa)
        if (SeatManager.dbFare > 0) {
            farePerSeat = SeatManager.dbFare;
            FarePerSeat.setText("PHP " + farePerSeat);
        }
        markBookedSeats();
    }

    // I-gray ang mga seat nga na-book na sa database
    private void markBookedSeats() {
        if (SeatManager.scheduleId <= 0
                && (from == null || to == null || travelDate == null || pickupTime == null)) {
            return;
        }

        javax.swing.JButton[] seatButtons = {
            btnSeats1,
            btnSeats2,
            btnSeats3,
            btnSeats4,
            btnSeats5,
            btnSeats6,
            btnSeats7,
            btnSeats8,
            btnSeats9,
            btnSeats10,
            btnSeats11,
            btnSeats12,
            btnSeats13,
            btnSeats14,
            btnSeats15,
            btnSeats16,
            btnSeats17,
            btnSeats18,
            btnSeats19,
            btnSeats20,
            btnSeats21,
            btnSeats22,
            btnSeats23,
            btnSeats24,
            btnSeats25,
            btnSeats26,
            btnSeats27,
            btnSeats28,
            btnSeats29,
            btnSeats30,
            btnSeats31,
            btnSeats32,
            btnSeats33,
            btnSeats34,
            btnSeats35,
            btnSeats36,
            btnSeats37,
            btnSeats38,
            btnSeats39,
            btnSeats40,
            btnSeats41,
            btnSeats42,
            btnSeats43,
            btnSeats44
        };

        java.util.ArrayList<Integer> booked;
        if (SeatManager.scheduleId > 0) {
            booked = Database.ScheduleDB.getBookedSeatsBySchedule(SeatManager.scheduleId);
        } else {
            booked = Database.ScheduleDB.getBookedSeats(from, to, travelDate, pickupTime);
        }

        for (javax.swing.JButton button : seatButtons) {
            int number = Integer.parseInt(button.getText());
            if (booked.contains(number)) {
                SeatManager.reserveSeat(button);
            }
        }
    }
    private boolean available;
private void setFare(String from, String to) {
    
    farePerSeat = 0;
    available = false;

    if ((from.equals("CDO") && to.equals("Wao"))
            || (from.equals("Wao") && to.equals("CDO"))) {

        farePerSeat = 350;
        available = true;

    } else if ((from.equals("CDO") && to.equals("Dipolog"))
            || (from.equals("Dipolog") && to.equals("CDO"))) {

        farePerSeat = 550;
        available = true;

    } else if ((from.equals("CDO") && to.equals("Pagadian"))
            || (from.equals("Pagadian") && to.equals("CDO"))) {

        farePerSeat = 450;
        available = true;

    } else if ((from.equals("CDO") && to.equals("Maramag"))
            || (from.equals("Maramag") && to.equals("CDO"))) {

        farePerSeat = 300;
        available = true;

    } else if ((from.equals("CDO") && to.equals("Tubod"))
            || (from.equals("Tubod") && to.equals("CDO"))) {

        farePerSeat = 400;
        available = true;

    } else if ((from.equals("CDO") && to.equals("Kibawe"))
            || (from.equals("Kibawe") && to.equals("CDO"))) {

        farePerSeat = 350;
        available = true;

    } else if ((from.equals("CDO") && to.equals("Ozamiz"))
            || (from.equals("Ozamiz") && to.equals("CDO"))) {

        farePerSeat = 300;
        available = true;
    }
    FarePerSeat.setText("PHP " + farePerSeat);
}



   private void updateFare() {

    String seats = "";
    int quantity = 0;

    if (btnSeats1.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "1, ";
        quantity++;
    }

    if (btnSeats2.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "2, ";
        quantity++;
    }

    if (btnSeats3.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "3, ";
        quantity++;
    }

    if (btnSeats4.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "4, ";
        quantity++;
    }

    if (btnSeats5.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "5, ";
        quantity++;
    }

    if (btnSeats6.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "6, ";
        quantity++;
    }

    if (btnSeats7.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "7, ";
        quantity++;
    }

    if (btnSeats8.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "8, ";
        quantity++;
    }

    if (btnSeats9.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "9, ";
        quantity++;
    }

    if (btnSeats10.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "10, ";
        quantity++;
    }

    if (btnSeats11.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "11, ";
        quantity++;
    }

    if (btnSeats12.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "12, ";
        quantity++;
    }

    if (btnSeats13.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "13, ";
        quantity++;
    }

    if (btnSeats14.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "14, ";
        quantity++;
    }

    if (btnSeats15.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "15, ";
        quantity++;
    }

    if (btnSeats16.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "16, ";
        quantity++;
    }

    if (btnSeats17.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "17, ";
        quantity++;
    }

    if (btnSeats18.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "18, ";
        quantity++;
    }

    if (btnSeats19.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "19, ";
        quantity++;
    }

    if (btnSeats20.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "20, ";
        quantity++;
    }

    if (btnSeats21.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "21, ";
        quantity++;
    }

    if (btnSeats22.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "22, ";
        quantity++;
    }

    if (btnSeats23.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "23, ";
        quantity++;
    }

    if (btnSeats24.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "24, ";
        quantity++;
    }

    if (btnSeats25.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "25, ";
        quantity++;
    }

    if (btnSeats26.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "26, ";
        quantity++;
    }

    if (btnSeats27.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "27, ";
        quantity++;
    }

    if (btnSeats28.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "28, ";
        quantity++;
    }

    if (btnSeats29.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "29, ";
        quantity++;
    }

    if (btnSeats30.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "30, ";
        quantity++;
    }

    if (btnSeats31.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "31, ";
        quantity++;
    }

    if (btnSeats32.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "32, ";
        quantity++;
    }

    if (btnSeats33.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "33, ";
        quantity++;
    }

    if (btnSeats34.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "34, ";
        quantity++;
    }

    if (btnSeats35.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "35, ";
        quantity++;
    }

    if (btnSeats36.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "36, ";
        quantity++;
    }

    if (btnSeats37.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "37, ";
        quantity++;
    }

    if (btnSeats38.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "38, ";
        quantity++;
    }

    if (btnSeats39.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "39, ";
        quantity++;
    }

    if (btnSeats40.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "40, ";
        quantity++;
    }

    if (btnSeats41.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "41, ";
        quantity++;
    }

    if (btnSeats42.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "42, ";
        quantity++;
    }

    if (btnSeats43.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "43, ";
        quantity++;
    }

    if (btnSeats44.getBackground().equals(java.awt.Color.BLUE)) {
        seats += "44, ";
        quantity++;
    }

    if (seats.endsWith(", ")) {
        seats = seats.substring(0, seats.length() - 2);
    }

    totalFare = quantity * farePerSeat;

    lblSelectedSeats.setText(seats);
    FarePerSeat.setText("PHP " + farePerSeat);
    lblTotalFare.setText("PHP " + totalFare);  
   }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblFarePerSeat = new javax.swing.JPanel();
        lblSeatMap1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        btnSeats4 = new javax.swing.JButton();
        btnSeats3 = new javax.swing.JButton();
        btnSeats5 = new javax.swing.JButton();
        btnSeats1 = new javax.swing.JButton();
        btnSeats8 = new javax.swing.JButton();
        btnSeats7 = new javax.swing.JButton();
        btnSeats12 = new javax.swing.JButton();
        btnSeats11 = new javax.swing.JButton();
        btnSeats15 = new javax.swing.JButton();
        btnSeats19 = new javax.swing.JButton();
        btnSeats23 = new javax.swing.JButton();
        btnSeats27 = new javax.swing.JButton();
        btnSeats31 = new javax.swing.JButton();
        btnSeats36 = new javax.swing.JButton();
        btnSeats16 = new javax.swing.JButton();
        btnSeats20 = new javax.swing.JButton();
        btnSeats24 = new javax.swing.JButton();
        btnSeats28 = new javax.swing.JButton();
        btnSeats32 = new javax.swing.JButton();
        btnSeats35 = new javax.swing.JButton();
        btnSeats40 = new javax.swing.JButton();
        btnSeats44 = new javax.swing.JButton();
        btnSeats39 = new javax.swing.JButton();
        btnSeats43 = new javax.swing.JButton();
        btnSeats2 = new javax.swing.JButton();
        btnSeats6 = new javax.swing.JButton();
        btnSeats10 = new javax.swing.JButton();
        btnSeats9 = new javax.swing.JButton();
        btnSeats13 = new javax.swing.JButton();
        btnSeats14 = new javax.swing.JButton();
        btnSeats18 = new javax.swing.JButton();
        btnSeats17 = new javax.swing.JButton();
        btnSeats21 = new javax.swing.JButton();
        btnSeats22 = new javax.swing.JButton();
        btnSeats30 = new javax.swing.JButton();
        btnSeats25 = new javax.swing.JButton();
        btnSeats29 = new javax.swing.JButton();
        btnSeats34 = new javax.swing.JButton();
        btnSeats26 = new javax.swing.JButton();
        btnSeats37 = new javax.swing.JButton();
        btnSeats33 = new javax.swing.JButton();
        btnSeats42 = new javax.swing.JButton();
        btnSeats41 = new javax.swing.JButton();
        btnSeats38 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        lblPickupTime = new javax.swing.JLabel();
        lbl = new javax.swing.JLabel();
        lblDropoff1 = new javax.swing.JLabel();
        cmbDropoff = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        cmbPickup = new javax.swing.JComboBox<>();
        lblSeatsSelected1 = new javax.swing.JLabel();
        lblFarePerSeat1 = new javax.swing.JLabel();
        lblTotalFare1 = new javax.swing.JLabel();
        FarePerSeat = new javax.swing.JLabel();
        lblSelectedSeats = new javax.swing.JLabel();
        lblTotalFare = new javax.swing.JLabel();
        btnProceed = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        lblDropoff2 = new javax.swing.JLabel();
        lblTripCode = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblFarePerSeat.setBackground(new java.awt.Color(250, 248, 227));
        lblFarePerSeat.setForeground(new java.awt.Color(255, 255, 255));

        lblSeatMap1.setBackground(new java.awt.Color(30, 105, 75));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Select your seat(s) here");

        btnSeats4.setText("4");
        btnSeats4.setPreferredSize(new java.awt.Dimension(64, 64));
        btnSeats4.addActionListener(this::btnSeats4ActionPerformed);

        btnSeats3.setText("3");
        btnSeats3.addActionListener(this::btnSeats3ActionPerformed);

        btnSeats5.setText("5");
        btnSeats5.addActionListener(this::btnSeats5ActionPerformed);

        btnSeats1.setText("1");
        btnSeats1.setPreferredSize(new java.awt.Dimension(64, 64));
        btnSeats1.addActionListener(this::btnSeats1ActionPerformed);

        btnSeats8.setText("8");
        btnSeats8.addActionListener(this::btnSeats8ActionPerformed);

        btnSeats7.setText("7");
        btnSeats7.addActionListener(this::btnSeats7ActionPerformed);

        btnSeats12.setText("12");
        btnSeats12.addActionListener(this::btnSeats12ActionPerformed);

        btnSeats11.setText("11");
        btnSeats11.addActionListener(this::btnSeats11ActionPerformed);

        btnSeats15.setText("15");
        btnSeats15.addActionListener(this::btnSeats15ActionPerformed);

        btnSeats19.setText("19");
        btnSeats19.addActionListener(this::btnSeats19ActionPerformed);

        btnSeats23.setText("23");
        btnSeats23.addActionListener(this::btnSeats23ActionPerformed);

        btnSeats27.setText("27");
        btnSeats27.addActionListener(this::btnSeats27ActionPerformed);

        btnSeats31.setText("31");
        btnSeats31.addActionListener(this::btnSeats31ActionPerformed);

        btnSeats36.setText("36");
        btnSeats36.addActionListener(this::btnSeats36ActionPerformed);

        btnSeats16.setText("16");
        btnSeats16.addActionListener(this::btnSeats16ActionPerformed);

        btnSeats20.setText("20");
        btnSeats20.addActionListener(this::btnSeats20ActionPerformed);

        btnSeats24.setText("24");
        btnSeats24.addActionListener(this::btnSeats24ActionPerformed);

        btnSeats28.setText("28");
        btnSeats28.addActionListener(this::btnSeats28ActionPerformed);

        btnSeats32.setText("32");
        btnSeats32.addActionListener(this::btnSeats32ActionPerformed);

        btnSeats35.setText("35");
        btnSeats35.addActionListener(this::btnSeats35ActionPerformed);

        btnSeats40.setText("40");
        btnSeats40.addActionListener(this::btnSeats40ActionPerformed);

        btnSeats44.setText("44");
        btnSeats44.addActionListener(this::btnSeats44ActionPerformed);

        btnSeats39.setText("39");
        btnSeats39.addActionListener(this::btnSeats39ActionPerformed);

        btnSeats43.setText("43");
        btnSeats43.addActionListener(this::btnSeats43ActionPerformed);

        btnSeats2.setText("2");
        btnSeats2.setPreferredSize(new java.awt.Dimension(64, 64));
        btnSeats2.addActionListener(this::btnSeats2ActionPerformed);

        btnSeats6.setText("6");
        btnSeats6.addActionListener(this::btnSeats6ActionPerformed);

        btnSeats10.setText("10");
        btnSeats10.addActionListener(this::btnSeats10ActionPerformed);

        btnSeats9.setText("9");
        btnSeats9.setPreferredSize(new java.awt.Dimension(64, 64));
        btnSeats9.addActionListener(this::btnSeats9ActionPerformed);

        btnSeats13.setText("13");
        btnSeats13.setPreferredSize(new java.awt.Dimension(64, 64));
        btnSeats13.addActionListener(this::btnSeats13ActionPerformed);

        btnSeats14.setText("14");
        btnSeats14.addActionListener(this::btnSeats14ActionPerformed);

        btnSeats18.setText("18");
        btnSeats18.addActionListener(this::btnSeats18ActionPerformed);

        btnSeats17.setText("17");
        btnSeats17.setPreferredSize(new java.awt.Dimension(64, 64));
        btnSeats17.addActionListener(this::btnSeats17ActionPerformed);

        btnSeats21.setText("21");
        btnSeats21.addActionListener(this::btnSeats21ActionPerformed);

        btnSeats22.setText("22");
        btnSeats22.addActionListener(this::btnSeats22ActionPerformed);

        btnSeats30.setText("30");
        btnSeats30.addActionListener(this::btnSeats30ActionPerformed);

        btnSeats25.setText("25");
        btnSeats25.addActionListener(this::btnSeats25ActionPerformed);

        btnSeats29.setText("29");
        btnSeats29.addActionListener(this::btnSeats29ActionPerformed);

        btnSeats34.setText("34");
        btnSeats34.addActionListener(this::btnSeats34ActionPerformed);

        btnSeats26.setText("26");
        btnSeats26.addActionListener(this::btnSeats26ActionPerformed);

        btnSeats37.setText("37");
        btnSeats37.addActionListener(this::btnSeats37ActionPerformed);

        btnSeats33.setText("33");
        btnSeats33.addActionListener(this::btnSeats33ActionPerformed);

        btnSeats42.setText("42");
        btnSeats42.addActionListener(this::btnSeats42ActionPerformed);

        btnSeats41.setText("41");
        btnSeats41.setPreferredSize(new java.awt.Dimension(64, 64));
        btnSeats41.addActionListener(this::btnSeats41ActionPerformed);

        btnSeats38.setText("38");
        btnSeats38.addActionListener(this::btnSeats38ActionPerformed);

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Bus Type ");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Regular AC ");

        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Amenities ");

        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("LEGEND");

        javax.swing.GroupLayout lblSeatMap1Layout = new javax.swing.GroupLayout(lblSeatMap1);
        lblSeatMap1.setLayout(lblSeatMap1Layout);
        lblSeatMap1Layout.setHorizontalGroup(
            lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lblSeatMap1Layout.createSequentialGroup()
                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(lblSeatMap1Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(lblSeatMap1Layout.createSequentialGroup()
                                .addComponent(btnSeats4, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnSeats3, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(lblSeatMap1Layout.createSequentialGroup()
                                    .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(btnSeats12, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSeats16, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSeats20, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSeats24, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSeats28, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSeats32, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSeats36, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSeats40, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSeats44, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(btnSeats15, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSeats11, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSeats19, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSeats23, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSeats27, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSeats31, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSeats35, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSeats39, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSeats43, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, lblSeatMap1Layout.createSequentialGroup()
                                    .addComponent(btnSeats8, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btnSeats7, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(lblSeatMap1Layout.createSequentialGroup()
                                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnSeats14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats18, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats22, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats26, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats30, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats34, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats38, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats42, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(lblSeatMap1Layout.createSequentialGroup()
                                        .addComponent(btnSeats5, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18))
                                    .addGroup(lblSeatMap1Layout.createSequentialGroup()
                                        .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(btnSeats41, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(btnSeats9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(btnSeats13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(btnSeats17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(btnSeats25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(btnSeats29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(btnSeats33, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(btnSeats37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(btnSeats21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(lblSeatMap1Layout.createSequentialGroup()
                                                .addGap(75, 75, 75)
                                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(lblSeatMap1Layout.createSequentialGroup()
                                                .addGap(71, 71, 71)
                                                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel10)))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, lblSeatMap1Layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
                                                .addComponent(jLabel8))))))
                            .addGroup(lblSeatMap1Layout.createSequentialGroup()
                                .addComponent(btnSeats2, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnSeats1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(lblSeatMap1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(227, 227, 227)))
                .addContainerGap(40, Short.MAX_VALUE))
        );
        lblSeatMap1Layout.setVerticalGroup(
            lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lblSeatMap1Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jLabel6)
                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(lblSeatMap1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSeats4, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSeats3, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSeats7, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSeats8, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSeats11, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSeats12, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, lblSeatMap1Layout.createSequentialGroup()
                        .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSeats1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSeats2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSeats6, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSeats5, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSeats9, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSeats10, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(lblSeatMap1Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel10)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(lblSeatMap1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnSeats16, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnSeats15, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnSeats13, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnSeats14, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(lblSeatMap1Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnSeats18, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats17, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(lblSeatMap1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnSeats20, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats19, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(6, 6, 6)
                        .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(lblSeatMap1Layout.createSequentialGroup()
                                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnSeats23, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats24, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnSeats28, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats27, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnSeats32, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats31, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnSeats36, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats35, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnSeats40, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats39, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnSeats44, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats43, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(lblSeatMap1Layout.createSequentialGroup()
                                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnSeats22, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats21, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnSeats26, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats25, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnSeats30, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats29, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnSeats34, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats33, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnSeats38, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats37, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(lblSeatMap1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnSeats42, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSeats41, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap(93, Short.MAX_VALUE))))
        );

        lblPickupTime.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblPickupTime.setText("8:00 AM");

        lbl.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbl.setText("Pick-up Time");

        lblDropoff1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblDropoff1.setText("Drop-off");

        cmbDropoff.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel14.setText("Pick-up");

        cmbPickup.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cmbPickup.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        cmbPickup.addActionListener(this::cmbPickupActionPerformed);

        lblSeatsSelected1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblSeatsSelected1.setText("Seat(s) Selected");

        lblFarePerSeat1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblFarePerSeat1.setText("Fare Per Seat  ");

        lblTotalFare1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTotalFare1.setText("Total Fare ");

        FarePerSeat.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        lblSelectedSeats.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        lblTotalFare.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        btnProceed.setBackground(new java.awt.Color(30, 105, 75));
        btnProceed.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnProceed.setForeground(new java.awt.Color(255, 255, 255));
        btnProceed.setText("PROCEED");
        btnProceed.addActionListener(this::btnProceedActionPerformed);

        btnBack.setBackground(new java.awt.Color(30, 105, 75));
        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.addActionListener(this::btnBackActionPerformed);

        lblDropoff2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblDropoff2.setText("Trip Code");

        lblTripCode.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTripCode.setText("SF1");

        javax.swing.GroupLayout lblFarePerSeatLayout = new javax.swing.GroupLayout(lblFarePerSeat);
        lblFarePerSeat.setLayout(lblFarePerSeatLayout);
        lblFarePerSeatLayout.setHorizontalGroup(
            lblFarePerSeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lblFarePerSeatLayout.createSequentialGroup()
                .addComponent(lblSeatMap1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(48, 48, 48)
                .addGroup(lblFarePerSeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(lblFarePerSeatLayout.createSequentialGroup()
                        .addGap(117, 117, 117)
                        .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(btnProceed, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, lblFarePerSeatLayout.createSequentialGroup()
                        .addGroup(lblFarePerSeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(lblFarePerSeatLayout.createSequentialGroup()
                                .addComponent(lblDropoff2, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblTripCode, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(lblFarePerSeatLayout.createSequentialGroup()
                                .addGroup(lblFarePerSeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblDropoff1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(lblFarePerSeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(lblFarePerSeatLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(lblPickupTime))
                                    .addGroup(lblFarePerSeatLayout.createSequentialGroup()
                                        .addGap(68, 68, 68)
                                        .addGroup(lblFarePerSeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(cmbDropoff, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(lblFarePerSeatLayout.createSequentialGroup()
                                                .addComponent(cmbPickup, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 0, Short.MAX_VALUE))))))
                            .addGroup(lblFarePerSeatLayout.createSequentialGroup()
                                .addGroup(lblFarePerSeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblSeatsSelected1, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblFarePerSeat1)
                                    .addComponent(lblTotalFare1))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(lblFarePerSeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(lblSelectedSeats, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(FarePerSeat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(lblTotalFare, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE))))
                        .addGap(92, 92, 92))))
        );
        lblFarePerSeatLayout.setVerticalGroup(
            lblFarePerSeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lblFarePerSeatLayout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addGroup(lblFarePerSeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPickupTime)
                    .addComponent(lbl))
                .addGap(18, 18, 18)
                .addGroup(lblFarePerSeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(cmbPickup, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(lblFarePerSeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cmbDropoff, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDropoff1))
                .addGap(18, 18, 18)
                .addGroup(lblFarePerSeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDropoff2)
                    .addComponent(lblTripCode))
                .addGap(45, 45, 45)
                .addGroup(lblFarePerSeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSeatsSelected1)
                    .addComponent(lblSelectedSeats))
                .addGap(18, 18, 18)
                .addGroup(lblFarePerSeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFarePerSeat1)
                    .addComponent(FarePerSeat))
                .addGap(26, 26, 26)
                .addGroup(lblFarePerSeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTotalFare1)
                    .addComponent(lblTotalFare))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(lblFarePerSeatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnProceed, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(108, 108, 108))
            .addGroup(lblFarePerSeatLayout.createSequentialGroup()
                .addComponent(lblSeatMap1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(lblFarePerSeat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(lblFarePerSeat, javax.swing.GroupLayout.PREFERRED_SIZE, 593, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSeats4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats4ActionPerformed
        SeatManager.selectSeat(btnSeats4);
         updateFare();
    }//GEN-LAST:event_btnSeats4ActionPerformed

    private void btnSeats3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats3ActionPerformed
        SeatManager.selectSeat(btnSeats3);
         updateFare();
    }//GEN-LAST:event_btnSeats3ActionPerformed

    private void btnSeats5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats5ActionPerformed
        SeatManager.selectSeat(btnSeats5);
         updateFare();
    }//GEN-LAST:event_btnSeats5ActionPerformed

    private void btnSeats1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats1ActionPerformed
        SeatManager.selectSeat(btnSeats1);
         updateFare();
    }//GEN-LAST:event_btnSeats1ActionPerformed

    private void btnSeats8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats8ActionPerformed
        SeatManager.selectSeat(btnSeats8);
         updateFare();
    }//GEN-LAST:event_btnSeats8ActionPerformed

    private void btnSeats7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats7ActionPerformed
        SeatManager.selectSeat(btnSeats7);
         updateFare();
    }//GEN-LAST:event_btnSeats7ActionPerformed

    private void btnSeats12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats12ActionPerformed
        SeatManager.selectSeat(btnSeats12);
         updateFare();
    }//GEN-LAST:event_btnSeats12ActionPerformed

    private void btnSeats11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats11ActionPerformed
        SeatManager.selectSeat(btnSeats11);
         updateFare();
    }//GEN-LAST:event_btnSeats11ActionPerformed

    private void btnSeats15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats15ActionPerformed
        SeatManager.selectSeat(btnSeats15);
         updateFare();
    }//GEN-LAST:event_btnSeats15ActionPerformed

    private void btnSeats16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats16ActionPerformed
        SeatManager.selectSeat(btnSeats16);
         updateFare();
    }//GEN-LAST:event_btnSeats16ActionPerformed

    private void btnSeats2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats2ActionPerformed
        SeatManager.selectSeat(btnSeats2);
         updateFare();
    }//GEN-LAST:event_btnSeats2ActionPerformed

    private void btnSeats6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats6ActionPerformed
        SeatManager.selectSeat(btnSeats6);
         updateFare();
    }//GEN-LAST:event_btnSeats6ActionPerformed

    private void btnSeats10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats10ActionPerformed
        SeatManager.selectSeat(btnSeats10);
         updateFare();
    }//GEN-LAST:event_btnSeats10ActionPerformed

    private void btnSeats9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats9ActionPerformed
        SeatManager.selectSeat(btnSeats9);
         updateFare();
    }//GEN-LAST:event_btnSeats9ActionPerformed

    private void btnSeats13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats13ActionPerformed
        SeatManager.selectSeat(btnSeats13);
         updateFare();
    }//GEN-LAST:event_btnSeats13ActionPerformed

    private void btnSeats14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats14ActionPerformed
        SeatManager.selectSeat(btnSeats14);
         updateFare();
    }//GEN-LAST:event_btnSeats14ActionPerformed

    private void btnSeats18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats18ActionPerformed
        SeatManager.selectSeat(btnSeats18);
         updateFare();
    }//GEN-LAST:event_btnSeats18ActionPerformed

    private void btnSeats17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats17ActionPerformed
        SeatManager.selectSeat(btnSeats17);
         updateFare();
    }//GEN-LAST:event_btnSeats17ActionPerformed

    private void cmbPickupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbPickupActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbPickupActionPerformed

    private void btnSeats19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats19ActionPerformed
        SeatManager.selectSeat(btnSeats19);
         updateFare();
    }//GEN-LAST:event_btnSeats19ActionPerformed

    private void btnSeats20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats20ActionPerformed
        SeatManager.selectSeat(btnSeats20);
         updateFare();
    }//GEN-LAST:event_btnSeats20ActionPerformed

    private void btnSeats21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats21ActionPerformed
        SeatManager.selectSeat(btnSeats21);
         updateFare();
    }//GEN-LAST:event_btnSeats21ActionPerformed

    private void btnSeats22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats22ActionPerformed
        SeatManager.selectSeat(btnSeats22);
         updateFare();
    }//GEN-LAST:event_btnSeats22ActionPerformed

    private void btnSeats23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats23ActionPerformed
        SeatManager.selectSeat(btnSeats23);
         updateFare();
    }//GEN-LAST:event_btnSeats23ActionPerformed

    private void btnSeats24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats24ActionPerformed
        SeatManager.selectSeat(btnSeats24);
         updateFare();
    }//GEN-LAST:event_btnSeats24ActionPerformed

    private void btnSeats27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats27ActionPerformed
        SeatManager.selectSeat(btnSeats27);
         updateFare();
    }//GEN-LAST:event_btnSeats27ActionPerformed

    private void btnSeats25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats25ActionPerformed
        SeatManager.selectSeat(btnSeats25);
         updateFare();
    }//GEN-LAST:event_btnSeats25ActionPerformed

    private void btnSeats26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats26ActionPerformed
        SeatManager.selectSeat(btnSeats26);
         updateFare();
    }//GEN-LAST:event_btnSeats26ActionPerformed

    private void btnSeats28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats28ActionPerformed
        SeatManager.selectSeat(btnSeats28);
         updateFare();
    }//GEN-LAST:event_btnSeats28ActionPerformed

    private void btnSeats29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats29ActionPerformed
        SeatManager.selectSeat(btnSeats29);
         updateFare();
    }//GEN-LAST:event_btnSeats29ActionPerformed

    private void btnSeats30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats30ActionPerformed
        SeatManager.selectSeat(btnSeats30);
         updateFare();
    }//GEN-LAST:event_btnSeats30ActionPerformed

    private void btnSeats31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats31ActionPerformed
        SeatManager.selectSeat(btnSeats31);
         updateFare();
    }//GEN-LAST:event_btnSeats31ActionPerformed

    private void btnSeats32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats32ActionPerformed
        SeatManager.selectSeat(btnSeats32);
        updateFare();
        
    }//GEN-LAST:event_btnSeats32ActionPerformed

    private void btnSeats33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats33ActionPerformed
        SeatManager.selectSeat(btnSeats33);
         updateFare();
    }//GEN-LAST:event_btnSeats33ActionPerformed

    private void btnSeats34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats34ActionPerformed
        SeatManager.selectSeat(btnSeats34);
         updateFare();
    }//GEN-LAST:event_btnSeats34ActionPerformed

    private void btnSeats35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats35ActionPerformed
        SeatManager.selectSeat(btnSeats35);
         updateFare();
    }//GEN-LAST:event_btnSeats35ActionPerformed

    private void btnSeats36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats36ActionPerformed
        SeatManager.selectSeat(btnSeats36);
         updateFare();
    }//GEN-LAST:event_btnSeats36ActionPerformed

    private void btnSeats37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats37ActionPerformed
        SeatManager.selectSeat(btnSeats37);
         updateFare();
    }//GEN-LAST:event_btnSeats37ActionPerformed
    private void btnSeats38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats38ActionPerformed
        SeatManager.selectSeat(btnSeats38);
         updateFare();
    }//GEN-LAST:event_btnSeats38ActionPerformed

    private void btnSeats39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats39ActionPerformed
        SeatManager.selectSeat(btnSeats39);
         updateFare();
    }//GEN-LAST:event_btnSeats39ActionPerformed

    private void btnSeats40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats40ActionPerformed
        SeatManager.selectSeat(btnSeats40);
         updateFare();
    }//GEN-LAST:event_btnSeats40ActionPerformed

    private void btnSeats41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats41ActionPerformed
        SeatManager.selectSeat(btnSeats41);
         updateFare();
    }//GEN-LAST:event_btnSeats41ActionPerformed

    private void btnSeats42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats42ActionPerformed
        SeatManager.selectSeat(btnSeats42);
         updateFare();
    }//GEN-LAST:event_btnSeats42ActionPerformed

    private void btnSeats43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats43ActionPerformed
        SeatManager.selectSeat(btnSeats43);
         updateFare();
    }//GEN-LAST:event_btnSeats43ActionPerformed

    private void btnSeats44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeats44ActionPerformed
        SeatManager.selectSeat(btnSeats44);
         updateFare();
    }//GEN-LAST:event_btnSeats44ActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
   PassengerDashboardFrame dashboard = new PassengerDashboardFrame();
    dashboard.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnProceedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProceedActionPerformed
    
        if (SeatManager.selectedSeats.isEmpty()) {

        JOptionPane.showMessageDialog(this,
                "Please select at least one seat.");

        return;
    }

    // Check usab kung naay naka-book na samtang nag-pili ka (double booking)
    if (SeatManager.scheduleId > 0) {
        java.util.ArrayList<Integer> bookedNow =
                Database.ScheduleDB.getBookedSeatsBySchedule(SeatManager.scheduleId);

        for (Integer seatNo : SeatManager.selectedSeats) {
            if (bookedNow.contains(seatNo)) {
                JOptionPane.showMessageDialog(this,
                        "Seat " + seatNo + " was just booked by someone else. Please choose another seat.");
                markBookedSeats();
                return;
            }
        }
    }

    PassengerDetailsFrame frame =
            new PassengerDetailsFrame();

    frame.from = from;
    frame.to = to;
    frame.travelDate = travelDate;
    frame.tripTime = tripTime;
    frame.pickupTime = pickupTime;
    frame.tripCode = tripCode;
    frame.busType = busType;

    frame.farePerSeat = farePerSeat;

    frame.selectedSeatCount =
            SeatManager.selectedSeats.size();

    frame.totalFare =
            farePerSeat * frame.selectedSeatCount;

    frame.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnProceedActionPerformed

    public static void main(String args[]) {
      
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> new ShowButtonFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel FarePerSeat;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnProceed;
    private javax.swing.JButton btnSeats1;
    private javax.swing.JButton btnSeats10;
    private javax.swing.JButton btnSeats11;
    private javax.swing.JButton btnSeats12;
    private javax.swing.JButton btnSeats13;
    private javax.swing.JButton btnSeats14;
    private javax.swing.JButton btnSeats15;
    private javax.swing.JButton btnSeats16;
    private javax.swing.JButton btnSeats17;
    private javax.swing.JButton btnSeats18;
    private javax.swing.JButton btnSeats19;
    private javax.swing.JButton btnSeats2;
    private javax.swing.JButton btnSeats20;
    private javax.swing.JButton btnSeats21;
    private javax.swing.JButton btnSeats22;
    private javax.swing.JButton btnSeats23;
    private javax.swing.JButton btnSeats24;
    private javax.swing.JButton btnSeats25;
    private javax.swing.JButton btnSeats26;
    private javax.swing.JButton btnSeats27;
    private javax.swing.JButton btnSeats28;
    private javax.swing.JButton btnSeats29;
    private javax.swing.JButton btnSeats3;
    private javax.swing.JButton btnSeats30;
    private javax.swing.JButton btnSeats31;
    private javax.swing.JButton btnSeats32;
    private javax.swing.JButton btnSeats33;
    private javax.swing.JButton btnSeats34;
    private javax.swing.JButton btnSeats35;
    private javax.swing.JButton btnSeats36;
    private javax.swing.JButton btnSeats37;
    private javax.swing.JButton btnSeats38;
    private javax.swing.JButton btnSeats39;
    private javax.swing.JButton btnSeats4;
    private javax.swing.JButton btnSeats40;
    private javax.swing.JButton btnSeats41;
    private javax.swing.JButton btnSeats42;
    private javax.swing.JButton btnSeats43;
    private javax.swing.JButton btnSeats44;
    private javax.swing.JButton btnSeats5;
    private javax.swing.JButton btnSeats6;
    private javax.swing.JButton btnSeats7;
    private javax.swing.JButton btnSeats8;
    private javax.swing.JButton btnSeats9;
    private javax.swing.JComboBox<String> cmbDropoff;
    private javax.swing.JComboBox<String> cmbPickup;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel lbl;
    private javax.swing.JLabel lblDropoff1;
    private javax.swing.JLabel lblDropoff2;
    private javax.swing.JPanel lblFarePerSeat;
    private javax.swing.JLabel lblFarePerSeat1;
    private javax.swing.JLabel lblPickupTime;
    private javax.swing.JPanel lblSeatMap1;
    private javax.swing.JLabel lblSeatsSelected1;
    private javax.swing.JLabel lblSelectedSeats;
    private javax.swing.JLabel lblTotalFare;
    private javax.swing.JLabel lblTotalFare1;
    private javax.swing.JLabel lblTripCode;
    // End of variables declaration//GEN-END:variables
}
